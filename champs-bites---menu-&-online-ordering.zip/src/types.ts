export type PizzaSize = 'S' | 'M' | 'L' | 'XL';

export interface PizzaSizes {
  S: number;
  M: number;
  L: number;
  XL: number;
}

export type MenuCategory = 'all' | 'pizza' | 'sandwich' | 'wrap' | 'starter' | 'burger' | 'dessert';

export interface MenuItem {
  id: number;
  cat: MenuCategory;
  name: string;
  desc: string;
  badge?: string;
  badgeType?: 'hot' | 'new' | 'def';
  price?: number;
  sizes?: PizzaSizes;
  img: string;
  isSpicy?: boolean;
  isVegetarian?: boolean;
}

export interface CrustOption {
  id: 'classic' | 'cheese_stuffed' | 'kabab_stuffed';
  name: string;
  price: number;
  description: string;
}

export interface AddonOption {
  id: string;
  name: string;
  price: number;
}

export interface CartItem {
  cartId: string;
  menuId: number;
  name: string;
  cat: MenuCategory;
  selectedSize?: PizzaSize;
  sizeLabel?: string;
  crust?: string;
  crustPrice?: number;
  addons?: { name: string; price: number }[];
  specialInstructions?: string;
  unitPrice: number;
  quantity: number;
  img: string;
}

export interface DealItem {
  id: string;
  name: string;
  type: 'starter' | 'burger' | 'mega';
  items: string[];
  price: number;
  oldPrice?: number;
  saveAmount?: number;
  tag?: string;
}

export interface OrderCustomerInfo {
  name: string;
  phone: string;
  address: string;
  notes?: string;
  landmark?: string;
  instructions?: string;
  orderType: 'delivery' | 'pickup';
}

export interface PlacedOrder {
  orderId: string;
  date: string;
  items: CartItem[];
  subtotal: number;
  deliveryFee: number;
  total: number;
  customer: OrderCustomerInfo;
  status: 'Received' | 'Preparing' | 'Out for Delivery' | 'Completed';
  estimatedMinutes: number;
}
