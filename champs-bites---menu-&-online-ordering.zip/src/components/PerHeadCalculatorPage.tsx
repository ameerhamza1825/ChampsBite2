import React, { useState } from 'react';
import { PARENT_MENU_ITEMS, MenuItemData, RESTAURANT_INFO } from '../data/parentSiteData';
import { PizzaSizeKey, PIZZA_SIZE_LABELS } from './ParentMenuCard';
import { CustomizedCartItem } from './ParentCustomizeModal';

interface PerHeadCalculatorPageProps {
  onBackToMenu: () => void;
  onAddToCart: (item: CustomizedCartItem) => void;
  onOpenCart: () => void;
}

interface SelectedPartyItem {
  id: string;
  name: string;
  sizeKey?: PizzaSizeKey;
  sizeLabel?: string;
  slices: number;
  unitPrice: number;
  quantity: number;
  image?: string;
}

const PIZZA_SLICES_MAP: Record<PizzaSizeKey, number> = {
  small: 4,
  medium: 6,
  large: 8,
  xl: 12,
};

export const PerHeadCalculatorPage: React.FC<PerHeadCalculatorPageProps> = ({
  onBackToMenu,
  onAddToCart,
  onOpenCart,
}) => {
  // Party Size (Persons)
  const [personsCount, setPersonsCount] = useState<number>(4);

  // Selected Pizza flavor for quick builder
  const pizzaItems = PARENT_MENU_ITEMS.filter((item) => item.isPizza && item.prices);
  const [selectedPizzaId, setSelectedPizzaId] = useState<string>(pizzaItems[0]?.id || 'ult-1');
  const [selectedSize, setSelectedSize] = useState<PizzaSizeKey>('large');

  // Party basket for American system calculation
  const [partyItems, setPartyItems] = useState<SelectedPartyItem[]>([
    {
      id: 'init-1',
      name: 'Malai Boti Pizza',
      sizeKey: 'large',
      sizeLabel: 'Large (12" - 8 Slices)',
      slices: 8,
      unitPrice: 1300,
      quantity: 1,
      image: PARENT_MENU_ITEMS[0]?.image,
    },
    {
      id: 'init-2',
      name: 'Chilled Soft Drink (1.5 Liter)',
      slices: 0,
      unitPrice: 230,
      quantity: 1,
      image: PARENT_MENU_ITEMS.find((it) => it.id === 'drk-2')?.image,
    },
  ]);

  const [copiedShare, setCopiedShare] = useState(false);
  const [addedToast, setAddedToast] = useState(false);

  const selectedPizza = pizzaItems.find((p) => p.id === selectedPizzaId) || pizzaItems[0];

  // Quick add current configured pizza to party calculation
  const handleAddPizzaToParty = () => {
    if (!selectedPizza || !selectedPizza.prices) return;
    const price = selectedPizza.prices[selectedSize];
    const slices = PIZZA_SLICES_MAP[selectedSize];
    const sizeLabel = `${PIZZA_SIZE_LABELS[selectedSize]} (${slices} Slices)`;

    const newItem: SelectedPartyItem = {
      id: `party-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      name: selectedPizza.name,
      sizeKey: selectedSize,
      sizeLabel,
      slices,
      unitPrice: price,
      quantity: 1,
      image: selectedPizza.image,
    };

    setPartyItems((prev) => [...prev, newItem]);
  };

  // Add popular party additions
  const handleAddPredefinedItem = (name: string, price: number, image?: string) => {
    const newItem: SelectedPartyItem = {
      id: `party-extra-${Date.now()}`,
      name,
      slices: 0,
      unitPrice: price,
      quantity: 1,
      image,
    };
    setPartyItems((prev) => [...prev, newItem]);
  };

  const handleUpdatePartyQty = (id: string, delta: number) => {
    setPartyItems((prev) =>
      prev
        .map((it) => {
          if (it.id === id) {
            const nq = it.quantity + delta;
            return nq > 0 ? { ...it, quantity: nq } : null;
          }
          return it;
        })
        .filter(Boolean) as SelectedPartyItem[]
    );
  };

  const handleRemovePartyItem = (id: string) => {
    setPartyItems((prev) => prev.filter((it) => it.id !== id));
  };

  // Calculations
  const totalBill = partyItems.reduce((sum, it) => sum + it.unitPrice * it.quantity, 0);
  const totalSlices = partyItems.reduce((sum, it) => sum + it.slices * it.quantity, 0);
  const perHeadCost = personsCount > 0 ? Math.ceil(totalBill / personsCount) : 0;
  const slicesPerPerson = personsCount > 0 ? (totalSlices / personsCount).toFixed(1) : '0';

  // Copy WhatsApp Split Message for Friends
  const handleCopyHisaabText = () => {
    let text = `🍕 *CHAMPS BITES PIZZA — PER HEAD HISAAB (AMERICAN SYSTEM)* 🍕\n`;
    text += `==============================\n`;
    text += `👥 *Total Afraad / Persons:* ${personsCount}\n`;
    text += `💰 *Grand Total Bill:* Rs. ${totalBill.toLocaleString()}\n`;
    text += `🎯 *PER HEAD SHARE (Har Bande Ka Hisaab):* *Rs. ${perHeadCost.toLocaleString()}*\n`;
    if (totalSlices > 0) {
      text += `🍕 *Slices Per Person:* approx ${slicesPerPerson} slices / person\n`;
    }
    text += `==============================\n`;
    text += `*Party Order Items:*\n`;
    partyItems.forEach((it, idx) => {
      text += `${idx + 1}. ${it.name} ${it.sizeLabel ? `(${it.sizeLabel})` : ''} x ${it.quantity} = Rs. ${(it.unitPrice * it.quantity).toLocaleString()}\n`;
    });
    text += `==============================\n`;
    text += `Order at Champs Bites Gujranwala (${RESTAURANT_INFO.phone}) · Free Delivery!`;

    navigator.clipboard.writeText(text);
    setCopiedShare(true);
    setTimeout(() => setCopiedShare(false), 2500);
  };

  // Add all party items to global cart & checkout
  const handleAddAllToCartAndOrder = () => {
    partyItems.forEach((it) => {
      const cartItem: CustomizedCartItem = {
        id: `perhead-${it.id}-${Date.now()}`,
        name: it.name,
        details: it.sizeLabel ? `${it.sizeLabel} • Per Head Calculation (${personsCount} persons: Rs. ${perHeadCost}/head)` : `Per Head Share Order (${personsCount} persons)`,
        price: it.unitPrice,
        quantity: it.quantity,
        image: it.image,
      };
      onAddToCart(cartItem);
    });

    setAddedToast(true);
    setTimeout(() => {
      setAddedToast(false);
      onOpenCart();
    }, 800);
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-white selection:bg-amber-400 selection:text-black">
      {/* Top Banner & Breadcrumb */}
      <div className="bg-gradient-to-r from-red-950 via-zinc-900 to-amber-950/70 border-b border-amber-500/20 py-4 px-4">
        <div className="container mx-auto flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={onBackToMenu}
            className="flex items-center gap-2 text-xs font-black text-amber-400 hover:text-white bg-zinc-900/90 border border-zinc-700/80 px-4 py-2 rounded-full transition-all cursor-pointer shadow active:scale-95"
          >
            <i className="fa-solid fa-arrow-left"></i>
            <span>← Back to Full Menu</span>
          </button>

          <div className="flex items-center gap-2">
            <span className="bg-emerald-500 text-zinc-950 text-[11px] font-black px-3 py-1 rounded-full uppercase tracking-wider flex items-center gap-1.5 shadow">
              <i className="fa-solid fa-users"></i>
              American System / Dutch Pay
            </span>
            <span className="hidden sm:inline text-xs text-zinc-400">
              Champs Bites Gujranwala
            </span>
          </div>
        </div>
      </div>

      <main className="container mx-auto px-4 py-8 sm:py-12 max-w-6xl">
        {/* Page Title & Explanation Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 space-y-3">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-500/20 to-orange-500/20 border border-amber-500/40 text-amber-400 text-xs font-black px-4 py-1.5 rounded-full uppercase tracking-wider">
            <i className="fa-solid fa-calculator text-sm"></i>
            <span>Pay Per Head &middot; American System &middot; Split Hisaab</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-black text-white font-heading tracking-tight">
            PER HEAD PAY <span className="gold-gradient-text">(AMERICAN SYSTEM)</span>
          </h1>

          <p className="text-zinc-300 text-xs sm:text-sm leading-relaxed">
            Pakistan me doston, college/university groups ya family ke sath pizza mangwate waqt <strong className="text-white">&ldquo;American System&rdquo; (Pay Per Head / Contri)</strong> hisaab lagana ab intehayi aasan hai! Har bande ke hissay ka bill aur slices live calculate karein.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Number of Persons & Pizza Addition (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            {/* 1. Persons Counter (American System Head Count) */}
            <div className="bg-zinc-900/90 border border-amber-500/30 rounded-3xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-base sm:text-lg font-black text-white font-heading flex items-center gap-2">
                    <i className="fa-solid fa-user-group text-amber-400"></i>
                    <span>1. Kitne Dost / Afraad Hain? (Head Count)</span>
                  </h3>
                  <p className="text-xs text-zinc-400 mt-0.5">
                    Select number of people sharing the pizza bill
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-3xl sm:text-4xl font-black text-amber-400 font-heading">
                    {personsCount}
                  </span>
                  <span className="text-[11px] text-zinc-400 block font-bold uppercase">Afraad / Heads</span>
                </div>
              </div>

              {/* Quick Stepper + Predefined Pills */}
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setPersonsCount((p) => Math.max(1, p - 1))}
                  className="w-11 h-11 rounded-2xl bg-zinc-800 hover:bg-zinc-700 text-white font-black text-lg flex items-center justify-center transition-all cursor-pointer active:scale-95 border border-zinc-700"
                >
                  -
                </button>
                <div className="flex-1 bg-zinc-950 border border-zinc-800 rounded-2xl py-2 px-4 text-center font-black text-lg text-white font-mono">
                  {personsCount} {personsCount === 1 ? 'Person (Solo)' : 'Persons (Party)'}
                </div>
                <button
                  type="button"
                  onClick={() => setPersonsCount((p) => p + 1)}
                  className="w-11 h-11 rounded-2xl bg-zinc-800 hover:bg-zinc-700 text-white font-black text-lg flex items-center justify-center transition-all cursor-pointer active:scale-95 border border-zinc-700"
                >
                  +
                </button>
              </div>

              {/* Predefined Quick Pills (2, 3, 4, 5, 6, 8, 10) */}
              <div className="flex flex-wrap items-center gap-2 mt-4 pt-3 border-t border-zinc-800">
                <span className="text-[11px] text-zinc-400 font-bold uppercase mr-1">Quick Set:</span>
                {[2, 3, 4, 5, 6, 8, 10, 12].map((num) => (
                  <button
                    key={num}
                    type="button"
                    onClick={() => setPersonsCount(num)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer border ${
                      personsCount === num
                        ? 'bg-amber-400 text-zinc-950 border-amber-300 shadow-md font-bold'
                        : 'bg-zinc-950 text-zinc-400 border-zinc-800 hover:border-zinc-700 hover:text-white'
                    }`}
                  >
                    {num} Heads
                  </button>
                ))}
              </div>
            </div>

            {/* 2. Add Pizza to Party Basket */}
            <div className="bg-zinc-900/90 border border-zinc-800 rounded-3xl p-5 sm:p-6 shadow-xl space-y-4">
              <h3 className="text-base sm:text-lg font-black text-white font-heading flex items-center gap-2">
                <i className="fa-solid fa-pizza-slice text-red-500"></i>
                <span>2. Select Pizza to Add to Party</span>
              </h3>

              {/* Pizza Flavor Picker */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">
                  Flavor:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {pizzaItems.map((pz) => {
                    const isPicked = pz.id === selectedPizzaId;
                    return (
                      <button
                        key={pz.id}
                        type="button"
                        onClick={() => setSelectedPizzaId(pz.id)}
                        className={`p-2.5 rounded-xl text-left border transition-all cursor-pointer ${
                          isPicked
                            ? 'bg-amber-400/20 border-amber-400 text-white shadow-md'
                            : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:border-zinc-700 hover:text-zinc-200'
                        }`}
                      >
                        <p className="text-xs font-extrabold truncate">{pz.name}</p>
                        <p className="text-[10px] text-amber-400 font-mono mt-0.5">
                          From Rs. {pz.prices?.small}
                        </p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Size Selector S M L XL */}
              <div className="space-y-1.5 pt-2">
                <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">
                  Size (S • M • L • XL):
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {(['small', 'medium', 'large', 'xl'] as PizzaSizeKey[]).map((sz) => {
                    const isSz = selectedSize === sz;
                    const pr = selectedPizza?.prices ? selectedPizza.prices[sz] : 0;
                    const sl = PIZZA_SLICES_MAP[sz];
                    const letter = sz === 'small' ? 'S (6")' : sz === 'medium' ? 'M (9")' : sz === 'large' ? 'L (12")' : 'XL (15")';
                    return (
                      <button
                        key={sz}
                        type="button"
                        onClick={() => setSelectedSize(sz)}
                        className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                          isSz
                            ? 'bg-amber-400 text-zinc-950 border-amber-300 shadow-md font-extrabold'
                            : 'bg-zinc-950 border-zinc-800 text-zinc-300 hover:border-zinc-700'
                        }`}
                      >
                        <div className="text-xs font-black">{letter}</div>
                        <div className="text-[10px] opacity-80">{sl} Slices</div>
                        <div className="text-[11px] font-mono font-bold mt-1">Rs. {pr}</div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Add to Party Basket Button */}
              <button
                type="button"
                onClick={handleAddPizzaToParty}
                className="w-full bg-gradient-to-r from-red-600 to-amber-500 hover:from-red-500 hover:to-amber-400 text-zinc-950 font-black py-3 rounded-2xl text-xs sm:text-sm uppercase tracking-wider transition-all shadow-md active:scale-98 flex items-center justify-center gap-2 cursor-pointer"
              >
                <i className="fa-solid fa-plus text-xs"></i>
                <span>Add {selectedPizza?.name} ({PIZZA_SIZE_LABELS[selectedSize]}) to Party Calculation</span>
              </button>

              {/* Quick Add Beverage / Sides Buttons */}
              <div className="pt-3 border-t border-zinc-800">
                <span className="text-[11px] text-zinc-400 font-bold uppercase block mb-2">
                  Quick Add Party Extras:
                </span>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => handleAddPredefinedItem('Chilled Soft Drink (1.5 Liter)', 230)}
                    className="bg-zinc-950 hover:bg-zinc-800 text-zinc-200 border border-zinc-800 text-xs px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    <i className="fa-solid fa-bottle-water text-emerald-400"></i>
                    <span>+ 1.5L Soft Drink (Rs. 230)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleAddPredefinedItem('Loaded Cheese Fries (Regular)', 700)}
                    className="bg-zinc-950 hover:bg-zinc-800 text-zinc-200 border border-zinc-800 text-xs px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    <i className="fa-solid fa-fire text-amber-400"></i>
                    <span>+ Loaded Fries (Rs. 700)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleAddPredefinedItem('Chilled Pure Mineral Water (1.5 Liter)', 100)}
                    className="bg-zinc-950 hover:bg-zinc-800 text-zinc-200 border border-zinc-800 text-xs px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    <i className="fa-solid fa-droplet text-blue-400"></i>
                    <span>+ 1.5L Mineral Water (Rs. 100)</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Live Per Head Hisaab Card & WhatsApp Split (5 cols) */}
          <div className="lg:col-span-5 bg-gradient-to-b from-zinc-900/95 via-zinc-950 to-zinc-900 border-2 border-emerald-500/40 rounded-3xl p-5 sm:p-6 shadow-2xl shadow-emerald-950/40 space-y-6 sticky top-24">
            {/* Live Per Head Main Highlight Badge */}
            <div className="bg-gradient-to-br from-emerald-600/20 via-zinc-900 to-amber-500/20 border border-emerald-500/50 rounded-2xl p-5 text-center relative overflow-hidden">
              <span className="text-xs font-black uppercase tracking-widest text-emerald-400 flex items-center justify-center gap-1.5 mb-1">
                <i className="fa-solid fa-receipt"></i>
                <span>AMERICAN SYSTEM &middot; PER HEAD SHARE</span>
              </span>

              <div className="text-4xl sm:text-5xl font-black text-amber-400 font-heading my-2">
                Rs. {perHeadCost.toLocaleString()}
                <span className="text-sm sm:text-base text-zinc-300 font-normal"> / person</span>
              </div>

              <div className="flex items-center justify-center gap-4 text-xs text-zinc-300 mt-2">
                <span className="bg-zinc-950/80 px-3 py-1 rounded-full border border-zinc-800">
                  👥 {personsCount} Afraad
                </span>
                {totalSlices > 0 && (
                  <span className="bg-zinc-950/80 px-3 py-1 rounded-full border border-zinc-800 text-amber-300 font-bold">
                    🍕 ~{slicesPerPerson} slices / head
                  </span>
                )}
              </div>
            </div>

            {/* Selected Party Items List */}
            <div className="space-y-3">
              <div className="flex items-center justify-between pb-1 border-b border-zinc-800 text-xs">
                <span className="font-extrabold text-zinc-300 uppercase tracking-wider">
                  Party Basket ({partyItems.length} items)
                </span>
                <span className="font-mono text-zinc-400">Total: Rs. {totalBill.toLocaleString()}</span>
              </div>

              {partyItems.length === 0 ? (
                <p className="text-xs text-zinc-500 text-center py-4">
                  Basket is empty. Select a pizza or side on the left to calculate!
                </p>
              ) : (
                <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                  {partyItems.map((item) => (
                    <div
                      key={item.id}
                      className="bg-zinc-950 p-2.5 rounded-xl border border-zinc-800/80 flex items-center justify-between gap-2 text-xs"
                    >
                      <div className="min-w-0 flex-1">
                        <p className="font-extrabold text-white truncate">{item.name}</p>
                        {item.sizeLabel && (
                          <p className="text-[10px] text-amber-400 truncate">{item.sizeLabel}</p>
                        )}
                        <p className="text-[10px] text-zinc-400">
                          Rs. {item.unitPrice} x {item.quantity} = <strong className="text-zinc-200">Rs. {item.unitPrice * item.quantity}</strong>
                        </p>
                      </div>

                      {/* Stepper */}
                      <div className="flex items-center gap-1.5">
                        <div className="flex items-center bg-zinc-900 border border-zinc-800 rounded-lg">
                          <button
                            type="button"
                            onClick={() => handleUpdatePartyQty(item.id, -1)}
                            className="w-5 h-5 text-zinc-400 hover:text-white flex items-center justify-center text-xs cursor-pointer"
                          >
                            -
                          </button>
                          <span className="text-xs font-bold px-1.5 text-white">{item.quantity}</span>
                          <button
                            type="button"
                            onClick={() => handleUpdatePartyQty(item.id, 1)}
                            className="w-5 h-5 text-zinc-400 hover:text-white flex items-center justify-center text-xs cursor-pointer"
                          >
                            +
                          </button>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleRemovePartyItem(item.id)}
                          className="text-red-400 hover:text-red-300 text-xs p-1 cursor-pointer"
                        >
                          <i className="fa-solid fa-xmark"></i>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Bill Summary */}
            <div className="space-y-1.5 text-xs border-t border-zinc-800 pt-3">
              <div className="flex justify-between text-zinc-400">
                <span>Total Food Bill:</span>
                <span className="font-bold text-white font-mono">Rs. {totalBill.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>Free Delivery in Gujranwala:</span>
                <span className="text-emerald-400 font-extrabold uppercase">FREE</span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>Divided Among ({personsCount} people):</span>
                <span className="text-amber-400 font-extrabold font-mono text-sm">Rs. {perHeadCost.toLocaleString()} each</span>
              </div>
            </div>

            {/* Action Buttons: WhatsApp Share Hisaab & Buy Now */}
            <div className="space-y-2.5 pt-2">
              {/* Copy WhatsApp Hisaab Button */}
              <button
                type="button"
                onClick={handleCopyHisaabText}
                className="w-full bg-zinc-800 hover:bg-zinc-700 text-white font-bold py-2.5 px-4 rounded-xl text-xs flex items-center justify-center gap-2 border border-zinc-700 transition-all cursor-pointer active:scale-95 shadow"
              >
                <i className={`fa-solid ${copiedShare ? 'fa-check text-emerald-400' : 'fa-share-nodes text-amber-400'}`}></i>
                <span>{copiedShare ? 'Copied WhatsApp Hisaab to Clipboard!' : 'Copy / Share Hisaab with Friends on WhatsApp'}</span>
              </button>

              {/* Order This Party on WhatsApp */}
              <button
                type="button"
                onClick={handleAddAllToCartAndOrder}
                className="w-full bg-gradient-to-r from-emerald-600 via-emerald-500 to-emerald-600 hover:from-emerald-500 hover:to-emerald-400 text-white font-black py-3.5 px-4 rounded-2xl text-sm flex items-center justify-center gap-2 shadow-xl shadow-emerald-950/60 transition-all active:scale-98 cursor-pointer ring-2 ring-emerald-500/30"
              >
                <i className="fa-brands fa-whatsapp text-xl"></i>
                <span>ORDER PARTY ON WHATSAPP &middot; Rs. {totalBill.toLocaleString()}</span>
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
