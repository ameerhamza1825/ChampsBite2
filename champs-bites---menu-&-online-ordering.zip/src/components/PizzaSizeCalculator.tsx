import React, { useState } from 'react';
import { PARENT_MENU_ITEMS, MenuItemData } from '../data/parentSiteData';
import { PizzaSizeKey, PIZZA_SIZE_LABELS } from './ParentMenuCard';
import { CustomizedCartItem } from './ParentCustomizeModal';

interface PizzaSizeCalculatorProps {
  onAddToCart: (customizedItem: CustomizedCartItem) => void;
}

interface SizeDetails {
  name: string;
  inches: string;
  slices: number;
  serves: string;
  badge?: string;
  scale: number; // For visual size animation
}

const SIZE_CONFIG: Record<PizzaSizeKey, SizeDetails> = {
  small: {
    name: 'Small',
    inches: '6 Inches',
    slices: 4,
    serves: '1 - 2 Persons',
    scale: 0.65,
  },
  medium: {
    name: 'Medium',
    inches: '9 Inches',
    slices: 6,
    serves: '2 - 3 Persons',
    badge: 'Most Popular',
    scale: 0.8,
  },
  large: {
    name: 'Large',
    inches: '12 Inches',
    slices: 8,
    serves: '4 - 5 Persons',
    scale: 0.95,
  },
  xl: {
    name: 'X-Large',
    inches: '15 Inches',
    slices: 12,
    serves: '6 - 8 Persons',
    badge: 'Best Family Value',
    scale: 1.1,
  },
};

const CRUST_OPTIONS = [
  { id: 'classic', name: 'Classic Golden Pan Crust', price: 0 },
  { id: 'cheese', name: 'Cheese Stuffed Crust', price: 200 },
  { id: 'kabab', name: 'Kabab Stuffed Crust', price: 200 },
];

export function PizzaSizeCalculator({ onAddToCart }: PizzaSizeCalculatorProps) {
  // Only pizza items
  const pizzaItems = PARENT_MENU_ITEMS.filter((item) => item.isPizza && item.prices);

  const [selectedPizzaId, setSelectedPizzaId] = useState<string>(pizzaItems[0]?.id || 'ult-1');
  const [selectedSize, setSelectedSize] = useState<PizzaSizeKey>('medium');
  const [selectedCrustId, setSelectedCrustId] = useState<string>('classic');
  const [extraCheese, setExtraCheese] = useState<boolean>(false);
  const [extraSauce, setExtraSauce] = useState<boolean>(false);
  const [quantity, setQuantity] = useState<number>(1);
  const [addedSuccess, setAddedSuccess] = useState<boolean>(false);

  const selectedPizza = pizzaItems.find((p) => p.id === selectedPizzaId) || pizzaItems[0];
  const sizeInfo = SIZE_CONFIG[selectedSize];
  const crust = CRUST_OPTIONS.find((c) => c.id === selectedCrustId) || CRUST_OPTIONS[0];

  // Calculation logic
  const baseSizePrice = selectedPizza?.prices ? selectedPizza.prices[selectedSize] : 850;
  const crustPrice = crust.price;
  const cheesePrice = extraCheese ? 200 : 0;
  const saucePrice = extraSauce ? 80 : 0;
  const unitPrice = baseSizePrice + crustPrice + cheesePrice + saucePrice;
  const totalPrice = unitPrice * quantity;
  const pricePerSlice = Math.round(unitPrice / sizeInfo.slices);

  const handleAddCalculatedToCart = () => {
    if (!selectedPizza) return;

    const details = [
      `Size: ${sizeInfo.name} (${sizeInfo.inches}, ${sizeInfo.slices} slices)`,
      crust.name !== 'Classic Golden Pan Crust' ? crust.name : null,
      extraCheese ? 'Extra Cheese (+Rs. 200)' : null,
      extraSauce ? 'Garlic Mayo Dip (+Rs. 80)' : null,
    ]
      .filter(Boolean)
      .join(' • ');

    const cartItem: CustomizedCartItem = {
      id: `${selectedPizza.id}-calc-${selectedSize}-${selectedCrustId}-${Date.now()}`,
      name: `${selectedPizza.name} (${sizeInfo.name} ${sizeInfo.inches})`,
      details,
      price: unitPrice,
      quantity,
      image: selectedPizza.image,
    };

    onAddToCart(cartItem);
    setAddedSuccess(true);
    setTimeout(() => setAddedSuccess(false), 2000);
  };

  return (
    <section id="pizzaCalculatorSection" className="mt-16 pt-8 border-t border-zinc-800/80">
      <div className="bg-gradient-to-b from-zinc-900/90 via-zinc-950 to-zinc-900 border border-amber-500/20 rounded-3xl p-6 sm:p-10 shadow-2xl relative overflow-hidden">
        {/* Subtle background glow */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-red-600/5 rounded-full blur-3xl pointer-events-none"></div>

        {/* Header */}
        <div className="relative z-10 mb-8 text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 bg-amber-400/10 border border-amber-400/30 text-amber-400 text-xs font-black px-3.5 py-1.5 rounded-full uppercase tracking-wider mb-3">
            <i className="fa-solid fa-calculator"></i>
            <span>Interactive Pizza Size &amp; Price Calculator</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-extrabold text-white font-heading tracking-tight">
            Pizza Sizing Calculator <span className="text-amber-400">S • M • L • XL</span>
          </h2>
          <p className="text-xs sm:text-sm text-zinc-400 mt-2 leading-relaxed">
            Calculate instant pricing, compare portion sizes, choose signature stuffed crusts, and customize portions for your party size.
          </p>

          {/* Quick How It Works 4-Step Flow Banner */}
          <div className="mt-5 grid grid-cols-2 sm:grid-cols-4 gap-2 text-left">
            <div className="bg-zinc-950/80 border border-zinc-800 rounded-2xl p-2.5 flex items-center gap-2.5">
              <span className="w-6 h-6 rounded-full bg-amber-400 text-zinc-950 font-black text-xs flex items-center justify-center flex-shrink-0">1</span>
              <div>
                <p className="text-[11px] font-black text-white">Flavor Pick</p>
                <p className="text-[10px] text-zinc-400">Choose favorite pizza</p>
              </div>
            </div>
            <div className="bg-zinc-950/80 border border-zinc-800 rounded-2xl p-2.5 flex items-center gap-2.5">
              <span className="w-6 h-6 rounded-full bg-amber-400 text-zinc-950 font-black text-xs flex items-center justify-center flex-shrink-0">2</span>
              <div>
                <p className="text-[11px] font-black text-white">Size S/M/L/XL</p>
                <p className="text-[10px] text-zinc-400">Slices &amp; portions</p>
              </div>
            </div>
            <div className="bg-zinc-950/80 border border-zinc-800 rounded-2xl p-2.5 flex items-center gap-2.5">
              <span className="w-6 h-6 rounded-full bg-amber-400 text-zinc-950 font-black text-xs flex items-center justify-center flex-shrink-0">3</span>
              <div>
                <p className="text-[11px] font-black text-white">Crust &amp; Add-ons</p>
                <p className="text-[10px] text-zinc-400">Stuffed cheese/kabab</p>
              </div>
            </div>
            <div className="bg-zinc-950/80 border border-zinc-800 rounded-2xl p-2.5 flex items-center gap-2.5">
              <span className="w-6 h-6 rounded-full bg-emerald-500 text-zinc-950 font-black text-xs flex items-center justify-center flex-shrink-0">4</span>
              <div>
                <p className="text-[11px] font-black text-emerald-400">Live Price &amp; Bag</p>
                <p className="text-[10px] text-zinc-400">1-click WhatsApp order</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start relative z-10">
          {/* Left Column: Configuration Controls (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            {/* 1. Flavor Selector */}
            <div className="space-y-2">
              <label className="text-xs font-extrabold text-zinc-300 uppercase tracking-wider flex items-center justify-between">
                <span>1. Select Pizza Flavor</span>
                <span className="text-amber-400 font-normal lowercase text-[11px]">
                  {pizzaItems.length} authentic options
                </span>
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {pizzaItems.map((pizza) => {
                  const isChosen = pizza.id === selectedPizzaId;
                  return (
                    <button
                      key={pizza.id}
                      type="button"
                      onClick={() => setSelectedPizzaId(pizza.id)}
                      className={`p-2.5 rounded-xl text-left transition-all border cursor-pointer flex flex-col justify-between ${
                        isChosen
                          ? 'bg-amber-400/15 border-amber-400 text-white shadow-md'
                          : 'bg-zinc-900/80 border-zinc-800 text-zinc-400 hover:text-zinc-200 hover:border-zinc-700'
                      }`}
                    >
                      <span className="text-xs font-extrabold line-clamp-1">{pizza.name}</span>
                      <span className="text-[10px] text-amber-400 font-mono mt-1">
                        From Rs. {pizza.prices?.small}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 2. Interactive S M L XL Size Calculation Selector */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-extrabold text-zinc-300 uppercase tracking-wider">
                  2. Choose Size (S • M • L • XL)
                </label>
                <span className="text-xs font-mono font-bold text-amber-400">
                  Base: Rs. {baseSizePrice}
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {(['small', 'medium', 'large', 'xl'] as PizzaSizeKey[]).map((szKey) => {
                  const isSelected = selectedSize === szKey;
                  const cfg = SIZE_CONFIG[szKey];
                  const price = selectedPizza?.prices ? selectedPizza.prices[szKey] : 0;
                  const letter = szKey === 'small' ? 'S' : szKey === 'medium' ? 'M' : szKey === 'large' ? 'L' : 'XL';

                  return (
                    <button
                      key={szKey}
                      type="button"
                      onClick={() => setSelectedSize(szKey)}
                      className={`relative p-3.5 rounded-2xl border text-center transition-all cursor-pointer flex flex-col items-center justify-between ${
                        isSelected
                          ? 'bg-gradient-to-b from-amber-400 to-amber-500 text-zinc-950 border-amber-300 shadow-lg shadow-amber-500/20 scale-[1.02]'
                          : 'bg-zinc-900/90 border-zinc-800 text-zinc-300 hover:border-zinc-700 hover:bg-zinc-850'
                      }`}
                    >
                      {cfg.badge && (
                        <span
                          className={`absolute -top-2 px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider shadow ${
                            isSelected
                              ? 'bg-zinc-950 text-amber-400 border border-amber-400/40'
                              : 'bg-amber-400 text-zinc-950'
                          }`}
                        >
                          {cfg.badge}
                        </span>
                      )}

                      <div className="text-2xl font-black font-heading mt-1">{letter}</div>
                      <div className={`text-xs font-bold ${isSelected ? 'text-zinc-900' : 'text-zinc-200'}`}>
                        {cfg.name}
                      </div>
                      <div className={`text-[11px] ${isSelected ? 'text-zinc-800' : 'text-zinc-400'} font-mono`}>
                        {cfg.inches}
                      </div>

                      <div
                        className={`mt-2 pt-2 border-t w-full text-xs font-extrabold font-mono ${
                          isSelected ? 'border-zinc-900/20 text-zinc-950' : 'border-zinc-800 text-amber-400'
                        }`}
                      >
                        Rs. {price}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 3. Crust Type Option */}
            <div className="space-y-2">
              <label className="text-xs font-extrabold text-zinc-300 uppercase tracking-wider">
                3. Signature Crust Upgrade
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {CRUST_OPTIONS.map((c) => {
                  const isPicked = selectedCrustId === c.id;
                  return (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => setSelectedCrustId(c.id)}
                      className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                        isPicked
                          ? 'bg-amber-400/20 border-amber-400 text-white'
                          : 'bg-zinc-900/70 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                      }`}
                    >
                      <span className="text-xs font-bold line-clamp-1">{c.name}</span>
                      <span className="text-[11px] font-mono text-amber-400 mt-1">
                        {c.price === 0 ? 'Included (Rs. 0)' : `+Rs. ${c.price}`}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 4. Add-ons and Extras */}
            <div className="space-y-2">
              <label className="text-xs font-extrabold text-zinc-300 uppercase tracking-wider">
                4. Delicious Extras
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <label
                  className={`flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer ${
                    extraCheese
                      ? 'bg-amber-400/15 border-amber-400 text-white'
                      : 'bg-zinc-900/70 border-zinc-800 text-zinc-400 hover:border-zinc-700'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <input
                      type="checkbox"
                      checked={extraCheese}
                      onChange={(e) => setExtraCheese(e.target.checked)}
                      className="w-4 h-4 rounded text-amber-500 focus:ring-amber-400 accent-amber-500"
                    />
                    <span className="text-xs font-bold text-zinc-200">Extra Mozzarella Melt</span>
                  </div>
                  <span className="text-xs font-mono text-amber-400">+Rs. 200</span>
                </label>

                <label
                  className={`flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer ${
                    extraSauce
                      ? 'bg-amber-400/15 border-amber-400 text-white'
                      : 'bg-zinc-900/70 border-zinc-800 text-zinc-400 hover:border-zinc-700'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <input
                      type="checkbox"
                      checked={extraSauce}
                      onChange={(e) => setExtraSauce(e.target.checked)}
                      className="w-4 h-4 rounded text-amber-500 focus:ring-amber-400 accent-amber-500"
                    />
                    <span className="text-xs font-bold text-zinc-200">Garlic Mayo Dip Cup</span>
                  </div>
                  <span className="text-xs font-mono text-amber-400">+Rs. 80</span>
                </label>
              </div>
            </div>
          </div>

          {/* Right Column: Live Calculation Summary & Visualizer (5 cols) */}
          <div className="lg:col-span-5 bg-zinc-950/80 rounded-2xl border border-zinc-800 p-5 sm:p-6 flex flex-col justify-between space-y-6">
            <div>
              {/* Live Pizza Visualizer */}
              <div className="relative aspect-[4/3] rounded-2xl bg-zinc-900 overflow-hidden border border-zinc-800/80 flex items-center justify-center p-4">
                <img
                  src={selectedPizza.image}
                  alt={selectedPizza.name}
                  className="w-full h-full object-cover rounded-xl transition-transform duration-500"
                  style={{ transform: `scale(${sizeInfo.scale})` }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-transparent to-transparent"></div>

                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
                  <div className="bg-zinc-950/90 backdrop-blur-md px-3 py-1 rounded-full border border-amber-400/40 text-[11px] font-black text-amber-400">
                    {sizeInfo.name} • {sizeInfo.inches}
                  </div>
                  <div className="bg-zinc-950/90 backdrop-blur-md px-3 py-1 rounded-full border border-zinc-700 text-[11px] font-bold text-zinc-300">
                    {sizeInfo.slices} Slices
                  </div>
                </div>
              </div>

              {/* Portion Metrics Grid */}
              <div className="grid grid-cols-3 gap-2 mt-4 text-center">
                <div className="bg-zinc-900/90 p-2.5 rounded-xl border border-zinc-800">
                  <span className="text-[10px] text-zinc-500 uppercase block font-semibold">Portion</span>
                  <span className="text-xs font-black text-white">{sizeInfo.serves}</span>
                </div>
                <div className="bg-zinc-900/90 p-2.5 rounded-xl border border-zinc-800">
                  <span className="text-[10px] text-zinc-500 uppercase block font-semibold">Slices</span>
                  <span className="text-xs font-black text-amber-400">{sizeInfo.slices} Slices</span>
                </div>
                <div className="bg-zinc-900/90 p-2.5 rounded-xl border border-zinc-800">
                  <span className="text-[10px] text-zinc-500 uppercase block font-semibold">Per Slice</span>
                  <span className="text-xs font-black text-emerald-400 font-mono">Rs. {pricePerSlice}</span>
                </div>
              </div>

              {/* Price Breakdown Calculation */}
              <div className="mt-5 space-y-2 border-t border-zinc-800/80 pt-4 text-xs">
                <div className="flex justify-between text-zinc-400">
                  <span>Base Price ({sizeInfo.name} - {selectedPizza.name}):</span>
                  <span className="font-mono text-zinc-200">Rs. {baseSizePrice}</span>
                </div>
                {crustPrice > 0 && (
                  <div className="flex justify-between text-zinc-400">
                    <span>{crust.name}:</span>
                    <span className="font-mono text-zinc-200">+Rs. {crustPrice}</span>
                  </div>
                )}
                {extraCheese && (
                  <div className="flex justify-between text-zinc-400">
                    <span>Extra Mozzarella Melt:</span>
                    <span className="font-mono text-zinc-200">+Rs. {cheesePrice}</span>
                  </div>
                )}
                {extraSauce && (
                  <div className="flex justify-between text-zinc-400">
                    <span>Garlic Mayo Dip:</span>
                    <span className="font-mono text-zinc-200">+Rs. {saucePrice}</span>
                  </div>
                )}
                <div className="flex justify-between text-zinc-400">
                  <span>Single Pizza Unit Total:</span>
                  <span className="font-mono text-amber-400 font-bold">Rs. {unitPrice}</span>
                </div>
              </div>
            </div>

            {/* Quantity Stepper & Final Add to Cart Button */}
            <div className="space-y-4 pt-4 border-t border-zinc-800">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-zinc-500 uppercase block font-bold">Total Calculation</span>
                  <div className="text-2xl font-black text-amber-400 font-heading">
                    Rs. {totalPrice.toLocaleString()}
                  </div>
                </div>

                {/* Quantity Controls */}
                <div className="flex items-center gap-2 bg-zinc-900 border border-zinc-800 rounded-xl p-1">
                  <button
                    type="button"
                    onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                    disabled={quantity <= 1}
                    className="w-8 h-8 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-white flex items-center justify-center font-bold text-sm disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                  >
                    -
                  </button>
                  <span className="w-8 text-center text-sm font-black text-white font-mono">
                    {quantity}
                  </span>
                  <button
                    type="button"
                    onClick={() => setQuantity((q) => q + 1)}
                    className="w-8 h-8 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-white flex items-center justify-center font-bold text-sm cursor-pointer"
                  >
                    +
                  </button>
                </div>
              </div>

              <button
                type="button"
                onClick={handleAddCalculatedToCart}
                className={`w-full py-3.5 px-6 rounded-2xl font-black text-sm uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xl ${
                  addedSuccess
                    ? 'bg-emerald-500 text-zinc-950 shadow-emerald-500/20'
                    : 'bg-gradient-to-r from-red-600 via-amber-500 to-amber-400 hover:opacity-95 text-zinc-950 shadow-amber-500/20 active:scale-[0.98]'
                }`}
              >
                {addedSuccess ? (
                  <>
                    <i className="fa-solid fa-circle-check"></i>
                    <span>Added {quantity}x to Order!</span>
                  </>
                ) : (
                  <>
                    <i className="fa-solid fa-cart-plus"></i>
                    <span>Add {quantity}x to Bag — Rs. {totalPrice.toLocaleString()}</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* 5. Comprehensive S vs M vs L vs XL Comparison Matrix Table */}
        <div className="mt-10 pt-8 border-t border-zinc-800/80">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-extrabold text-white uppercase tracking-wider font-heading flex items-center gap-2">
              <i className="fa-solid fa-table-cells text-amber-400"></i>
              <span>Portion &amp; Value Comparison (S vs M vs L vs XL)</span>
            </h3>
            <span className="text-[11px] text-zinc-400">For {selectedPizza.name}</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-zinc-800 text-[11px] font-black uppercase text-zinc-400 tracking-wider">
                  <th className="py-2.5 px-3">Size Key</th>
                  <th className="py-2.5 px-3">Diameter</th>
                  <th className="py-2.5 px-3">Slices</th>
                  <th className="py-2.5 px-3">Serves</th>
                  <th className="py-2.5 px-3">Calculated Price</th>
                  <th className="py-2.5 px-3">Cost / Slice</th>
                  <th className="py-2.5 px-3 text-right">Quick Pick</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/60">
                {(['small', 'medium', 'large', 'xl'] as PizzaSizeKey[]).map((szKey) => {
                  const cfg = SIZE_CONFIG[szKey];
                  const price = selectedPizza?.prices ? selectedPizza.prices[szKey] : 0;
                  const perSlice = Math.round(price / cfg.slices);
                  const isCurrent = selectedSize === szKey;
                  const letter = szKey === 'small' ? 'S' : szKey === 'medium' ? 'M' : szKey === 'large' ? 'L' : 'XL';

                  return (
                    <tr
                      key={szKey}
                      onClick={() => setSelectedSize(szKey)}
                      className={`transition-colors cursor-pointer ${
                        isCurrent ? 'bg-amber-400/10 font-bold text-white' : 'text-zinc-300 hover:bg-zinc-800/40'
                      }`}
                    >
                      <td className="py-3 px-3 flex items-center gap-2">
                        <span
                          className={`w-6 h-6 rounded-md font-black flex items-center justify-center text-xs ${
                            isCurrent ? 'bg-amber-400 text-zinc-950' : 'bg-zinc-800 text-zinc-300'
                          }`}
                        >
                          {letter}
                        </span>
                        <span className="font-extrabold">{cfg.name}</span>
                      </td>
                      <td className="py-3 px-3 font-mono text-zinc-400">{cfg.inches}</td>
                      <td className="py-3 px-3">{cfg.slices} Slices</td>
                      <td className="py-3 px-3 text-zinc-300">{cfg.serves}</td>
                      <td className="py-3 px-3 font-mono font-extrabold text-amber-400">Rs. {price}</td>
                      <td className="py-3 px-3 font-mono text-emerald-400">Rs. {perSlice}</td>
                      <td className="py-3 px-3 text-right">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedSize(szKey);
                          }}
                          className={`px-3 py-1 rounded-lg text-[11px] font-black transition-all cursor-pointer ${
                            isCurrent
                              ? 'bg-amber-400 text-zinc-950 font-bold'
                              : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-300'
                          }`}
                        >
                          {isCurrent ? 'Selected' : 'Select'}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
}
