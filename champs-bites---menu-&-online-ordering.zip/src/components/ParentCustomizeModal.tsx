import { useState, useEffect } from 'react';
import { MenuItemData } from '../data/parentSiteData';
import { PizzaSizeKey, PIZZA_SIZE_LABELS } from './ParentMenuCard';

export interface CustomizedCartItem {
  id: string;
  name: string;
  details: string;
  price: number;
  quantity: number;
  image?: string;
}

interface ParentCustomizeModalProps {
  item: MenuItemData | null;
  preselectedSize?: PizzaSizeKey;
  onClose: () => void;
  onAddToCart: (customizedItem: CustomizedCartItem) => void;
}

export function ParentCustomizeModal({
  item,
  preselectedSize = 'medium',
  onClose,
  onAddToCart,
}: ParentCustomizeModalProps) {
  const [selectedSize, setSelectedSize] = useState<PizzaSizeKey>(preselectedSize);
  const [selectedCrust, setSelectedCrust] = useState<{ name: string; price: number }>({
    name: 'Pan Crust',
    price: 0,
  });
  const [extraCheese, setExtraCheese] = useState(false);
  const [extraChicken, setExtraChicken] = useState(false);
  const [instructions, setInstructions] = useState('');

  useEffect(() => {
    if (preselectedSize) {
      setSelectedSize(preselectedSize);
    }
  }, [preselectedSize, item]);

  if (!item) return null;

  // Base price
  let basePrice = 0;
  if (item.isPizza && item.prices) {
    basePrice = item.prices[selectedSize];
  } else if (item.isCrown && item.variants) {
    basePrice = item.variants[0].price;
  } else {
    basePrice = item.price || 0;
  }

  // Toppings total
  const cheesePrice = extraCheese ? 200 : 0;
  const chickenPrice = extraChicken ? 150 : 0;
  const totalPrice = basePrice + selectedCrust.price + cheesePrice + chickenPrice;

  const handleConfirm = () => {
    let details = `Size: ${PIZZA_SIZE_LABELS[selectedSize].toUpperCase()}`;
    if (selectedCrust.name !== 'Pan Crust') {
      details += ` | ${selectedCrust.name}`;
    }
    const toppings: string[] = [];
    if (extraCheese) toppings.push('Extra Cheese (+Rs. 200)');
    if (extraChicken) toppings.push('Extra Chicken (+Rs. 150)');
    if (toppings.length > 0) {
      details += ` | ${toppings.join(', ')}`;
    }
    if (instructions.trim()) {
      details += ` (${instructions.trim()})`;
    }

    const cartItem: CustomizedCartItem = {
      id: `${item.id}-${Date.now()}`,
      name: item.name,
      details,
      price: totalPrice,
      quantity: 1,
      image: item.image,
    };

    onAddToCart(cartItem);
    onClose();
  };

  const crustOptions = [
    { name: 'Pan Crust', price: 0, sub: 'Standard' },
    { name: 'Thin Crust', price: 150, sub: '+Rs. 150' },
    { name: 'Cheese Stuffed Crust', price: 350, sub: '+Rs. 350' },
    { name: 'Kebab Stuffed Crust', price: 400, sub: '+Rs. 400' },
  ];

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-zinc-900 border border-zinc-800 w-full max-w-lg rounded-3xl overflow-hidden shadow-2xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="relative bg-zinc-950 p-5 border-b border-zinc-800 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-extrabold text-amber-400 uppercase tracking-widest">
              Custom Pizza Studio
            </span>
            <h3 className="text-xl font-extrabold text-white font-heading mt-0.5">{item.name}</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-zinc-800 text-zinc-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <i className="fa-solid fa-xmark text-base"></i>
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-5 overflow-y-auto space-y-6 flex-1 text-sm">
          {/* 1. Select Size */}
          {item.isPizza && item.prices && (
            <div>
              <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-2.5">
                1. Select Size <span className="text-red-500">*</span>
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {(['small', 'medium', 'large', 'xl'] as PizzaSizeKey[]).map((szKey) => {
                  const isChecked = selectedSize === szKey;
                  return (
                    <button
                      key={szKey}
                      type="button"
                      onClick={() => setSelectedSize(szKey)}
                      className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                        isChecked
                          ? 'border-amber-400 bg-amber-400/10 text-white'
                          : 'border-zinc-800 bg-zinc-950 text-zinc-400 hover:border-zinc-700'
                      }`}
                    >
                      <p className={`text-xs font-bold ${isChecked ? 'text-amber-400' : 'text-white'}`}>
                        {PIZZA_SIZE_LABELS[szKey]}
                      </p>
                      <p className="text-[11px] text-zinc-400 mt-0.5">Rs. {item.prices![szKey]}</p>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* 2. Crust Preference */}
          <div>
            <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-2.5">
              2. Crust Style
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {crustOptions.map((c) => {
                const isSelected = selectedCrust.name === c.name;
                return (
                  <button
                    key={c.name}
                    type="button"
                    onClick={() => setSelectedCrust({ name: c.name, price: c.price })}
                    className={`p-2.5 rounded-xl border text-left flex justify-between items-center transition-all cursor-pointer ${
                      isSelected
                        ? 'border-amber-400 bg-amber-400/10 text-white'
                        : 'border-zinc-800 bg-zinc-950 text-zinc-400 hover:border-zinc-700'
                    }`}
                  >
                    <span className="text-xs font-semibold text-white">{c.name}</span>
                    <span className={`text-[10px] ${c.price > 0 ? 'text-amber-400 font-bold' : 'text-zinc-400'}`}>
                      {c.sub}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 3. Extra Toppings */}
          <div>
            <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-2.5">
              3. Extra Toppings (Optional)
            </label>
            <div className="space-y-2">
              <button
                type="button"
                onClick={() => setExtraCheese(!extraCheese)}
                className={`w-full flex items-center justify-between p-2.5 rounded-xl border transition-all cursor-pointer ${
                  extraCheese
                    ? 'border-amber-400 bg-amber-400/10 text-white'
                    : 'border-zinc-800 bg-zinc-950 text-zinc-400 hover:border-zinc-700'
                }`}
              >
                <div className="flex items-center gap-2">
                  <div
                    className={`w-4 h-4 rounded border flex items-center justify-center text-xs ${
                      extraCheese ? 'bg-amber-400 border-amber-400 text-black' : 'border-zinc-700 bg-zinc-900'
                    }`}
                  >
                    {extraCheese && <i className="fa-solid fa-check text-[10px]"></i>}
                  </div>
                  <span className="text-xs text-white">Extra Cheese Topping</span>
                </div>
                <span className="text-[11px] text-amber-400 font-bold">+Rs. 200</span>
              </button>

              <button
                type="button"
                onClick={() => setExtraChicken(!extraChicken)}
                className={`w-full flex items-center justify-between p-2.5 rounded-xl border transition-all cursor-pointer ${
                  extraChicken
                    ? 'border-amber-400 bg-amber-400/10 text-white'
                    : 'border-zinc-800 bg-zinc-950 text-zinc-400 hover:border-zinc-700'
                }`}
              >
                <div className="flex items-center gap-2">
                  <div
                    className={`w-4 h-4 rounded border flex items-center justify-center text-xs ${
                      extraChicken ? 'bg-amber-400 border-amber-400 text-black' : 'border-zinc-700 bg-zinc-900'
                    }`}
                  >
                    {extraChicken && <i className="fa-solid fa-check text-[10px]"></i>}
                  </div>
                  <span className="text-xs text-white">Extra Chicken Chunks</span>
                </div>
                <span className="text-[11px] text-amber-400 font-bold">+Rs. 150</span>
              </button>
            </div>
          </div>

          {/* Special Instructions */}
          <div>
            <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
              Special Cooking Instructions
            </label>
            <input
              type="text"
              placeholder="e.g. Extra spicy, well-done crust, lighter cheese..."
              value={instructions}
              onChange={(e) => setInstructions(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400"
            />
          </div>
        </div>

        {/* Modal Footer */}
        <div className="bg-zinc-950 p-4 border-t border-zinc-800 flex items-center justify-between gap-4">
          <div>
            <p className="text-[10px] text-zinc-400 uppercase font-semibold">Total Price</p>
            <p className="text-2xl font-extrabold text-amber-400 font-heading">
              Rs. {totalPrice.toLocaleString()}
            </p>
          </div>
          <button
            type="button"
            onClick={handleConfirm}
            className="flex-1 bg-gradient-to-r from-red-600 to-amber-500 hover:from-red-500 hover:to-amber-400 text-zinc-950 font-extrabold py-3 px-5 rounded-2xl text-sm shadow-lg shadow-red-900/30 flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-95"
          >
            <i className="fa-solid fa-cart-plus"></i>
            <span>ADD TO CART</span>
          </button>
        </div>
      </div>
    </div>
  );
}
