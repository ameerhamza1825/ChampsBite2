import { Bike, Timer, Sparkles, Moon } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/menuData';

export function FeaturesBar() {
  const features = [
    {
      icon: Bike,
      title: 'City-wide Delivery',
      desc: 'Free for orders over Rs. 2,000',
    },
    {
      icon: Timer,
      title: 'Oven-Hot Guarantee',
      desc: 'Delivered fresh in thermal insulated bags',
    },
    {
      icon: Sparkles,
      title: '100% Quality Ingredients',
      desc: 'Pure whole-milk mozzarella & fresh chicken',
    },
    {
      icon: Moon,
      title: 'Late Night Cravings',
      desc: `Open daily ${RESTAURANT_INFO.openingHours}`,
    },
  ];

  return (
    <div className="bg-neutral-900 border-b border-neutral-800 py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feat, idx) => {
            const Icon = feat.icon;
            return (
              <div key={idx} className="flex items-center gap-3.5 p-2">
                <div className="w-10 h-10 rounded-lg bg-neutral-800 border border-neutral-700/60 flex items-center justify-center shrink-0 text-amber-500">
                  <Icon className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xs sm:text-sm font-bold text-white tracking-tight">{feat.title}</h3>
                  <p className="text-[11px] text-neutral-400 mt-0.5">{feat.desc}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
