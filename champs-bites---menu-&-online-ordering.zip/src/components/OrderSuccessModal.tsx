import { CheckCircle2, Clock, MapPin, Phone, MessageCircle, X } from 'lucide-react';
import { PlacedOrder } from '../types';
import { RESTAURANT_INFO } from '../data/menuData';

interface OrderSuccessModalProps {
  order: PlacedOrder | null;
  onClose: () => void;
}

export function OrderSuccessModal({ order, onClose }: OrderSuccessModalProps) {
  if (!order) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="order-success-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200"
    >
      <div className="relative w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header with success badge */}
        <div className="p-6 bg-gradient-to-b from-neutral-950 to-neutral-900 border-b border-neutral-800 text-center relative">
          <button
            type="button"
            onClick={onClose}
            aria-label="Close dialog"
            className="absolute top-4 right-4 p-1.5 text-neutral-400 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="w-14 h-14 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto mb-3">
            <CheckCircle2 className="w-8 h-8 stroke-[2.5]" />
          </div>

          <div className="text-xs uppercase tracking-widest text-amber-500 font-bold">
            Order Confirmed!
          </div>
          <h2 id="order-success-title" className="text-2xl font-extrabold text-white mt-1 font-display">
            Order #{order.orderId}
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            Thank you, {order.customer.name}! We have received your order and the kitchen is firing up the oven.
          </p>
        </div>

        {/* Status / ETA bar */}
        <div className="px-6 py-3.5 bg-neutral-950 border-b border-neutral-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-neutral-300">
            <Clock className="w-4 h-4 text-amber-500" />
            <span>Estimated Delivery: <strong className="text-white font-mono">{order.estimatedMinutes} mins</strong></span>
          </div>

          <span className="text-emerald-400 font-bold bg-emerald-950/60 border border-emerald-800/50 px-2 py-0.5 rounded text-[11px]">
            Kitchen Preparing
          </span>
        </div>

        {/* Receipt Content */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1 text-xs sm:text-sm">
          {/* Customer info */}
          <div className="bg-neutral-950/60 border border-neutral-800 p-3.5 rounded-xl space-y-1.5 text-neutral-300 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-neutral-500">Contact Number:</span>
              <span className="font-mono text-white">{order.customer.phone}</span>
            </div>
            {order.customer.orderType === 'delivery' && (
              <div className="flex items-start justify-between gap-4">
                <span className="text-neutral-500 shrink-0 flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-amber-500" />
                  Address:
                </span>
                <span className="text-right text-white break-words">{order.customer.address}</span>
              </div>
            )}
            <div className="flex items-center justify-between">
              <span className="text-neutral-500">Service:</span>
              <span className="text-amber-400 font-semibold">
                {order.customer.orderType === 'delivery' ? 'Home Delivery' : 'Self Pickup'}
              </span>
            </div>
          </div>

          {/* Itemized breakdown */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-400 mb-2">
              Itemized Summary
            </h4>
            <div className="space-y-2 border-y border-neutral-800 py-3">
              {order.items.map((item, idx) => (
                <div key={idx} className="flex justify-between items-start gap-3 text-xs">
                  <div>
                    <span className="font-bold text-white">
                      {item.quantity}x {item.name}
                    </span>
                    {item.sizeLabel && (
                      <span className="text-neutral-400 block text-[11px]">{item.sizeLabel}</span>
                    )}
                    {item.crust && (
                      <span className="text-amber-400 block text-[11px]">Crust: {item.crust}</span>
                    )}
                    {item.addons && item.addons.length > 0 && (
                      <span className="text-neutral-400 block text-[11px]">
                        Add-ons: {item.addons.map((a) => a.name).join(', ')}
                      </span>
                    )}
                  </div>
                  <span className="font-mono tabular-nums text-white shrink-0">
                    Rs. {(item.unitPrice * item.quantity).toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Pricing Totals */}
          <div className="space-y-1.5 text-xs">
            <div className="flex justify-between text-neutral-400">
              <span>Subtotal</span>
              <span className="font-mono tabular-nums text-white">Rs. {order.subtotal.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-neutral-400">
              <span>Delivery Fee</span>
              <span className="font-mono tabular-nums">
                {order.deliveryFee === 0 ? (
                  <span className="text-emerald-400 font-bold">FREE</span>
                ) : (
                  `Rs. ${order.deliveryFee}`
                )}
              </span>
            </div>
            <div className="flex justify-between text-sm sm:text-base font-extrabold text-white pt-2 border-t border-neutral-800">
              <span>Grand Total</span>
              <span className="text-amber-400 font-mono tabular-nums">
                Rs. {order.total.toLocaleString()}
              </span>
            </div>
            <p className="text-[11px] text-neutral-500 text-right">Payment via Cash on Delivery</p>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 sm:p-5 border-t border-neutral-800 bg-neutral-950 flex flex-wrap gap-2">
          <a
            href={`https://wa.me/${RESTAURANT_INFO.whatsappRaw}?text=${encodeURIComponent(
              `Hi Champs Bites, checking status for Order #${order.orderId}.`
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-1.5"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Chat on WhatsApp</span>
          </a>

          <a
            href={`tel:${RESTAURANT_INFO.phone}`}
            className="flex-1 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 hover:text-white font-semibold text-xs rounded-xl transition-all flex items-center justify-center gap-1.5"
          >
            <Phone className="w-4 h-4 text-amber-500" />
            <span>Call Restaurant</span>
          </a>
        </div>
      </div>
    </div>
  );
}
