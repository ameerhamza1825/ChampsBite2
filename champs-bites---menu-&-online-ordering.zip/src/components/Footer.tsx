import { Phone, MessageCircle, MapPin, Clock, Bike, ArrowUp } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/menuData';
import { AppView } from './Header';

interface FooterProps {
  onNavigate?: (view: AppView) => void;
}

export function Footer({ onNavigate }: FooterProps) {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLink = (view: AppView) => {
    if (onNavigate) {
      onNavigate(view);
      scrollToTop();
    }
  };

  return (
    <footer id="contact" className="bg-neutral-950 border-t border-neutral-800 pt-16 pb-12 text-neutral-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 mb-12">
          {/* Brand Info */}
          <div className="lg:col-span-4 space-y-4">
            <button
              type="button"
              onClick={() => handleLink('home')}
              className="text-2xl font-extrabold font-display text-white tracking-tight inline-block text-left cursor-pointer"
            >
              CHAMPS <span className="text-amber-500">BITES</span>
            </button>
            <p className="text-neutral-400 leading-relaxed max-w-sm">
              Serving handcrafted stone-baked pizzas, signature stuffed crusts, and crispy zinger burgers with premium ingredients and fast citywide delivery.
            </p>
            <div className="flex items-center gap-3 pt-2">
              <a
                href={`https://wa.me/${RESTAURANT_INFO.whatsappRaw}`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3.5 py-2 bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-800/40 text-emerald-400 font-semibold rounded-lg transition-colors flex items-center gap-2"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp Order</span>
              </a>
              <a
                href={`tel:${RESTAURANT_INFO.phone}`}
                className="px-3.5 py-2 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-200 font-semibold rounded-lg transition-colors flex items-center gap-2"
              >
                <Phone className="w-4 h-4 text-amber-500" />
                <span>Call Hotline</span>
              </a>
            </div>
          </div>

          {/* Quick links */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">Menu &amp; Deals</h4>
            <ul className="space-y-2">
              <li>
                <button
                  type="button"
                  onClick={() => handleLink('menu')}
                  className="hover:text-amber-400 transition-colors cursor-pointer text-left"
                >
                  Signature Pizzas
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleLink('deals')}
                  className="hover:text-amber-400 transition-colors cursor-pointer text-left"
                >
                  Value Burger Combos
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleLink('deals')}
                  className="hover:text-amber-400 transition-colors cursor-pointer text-left"
                >
                  Starter Feasts
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleLink('menu')}
                  className="hover:text-amber-400 transition-colors cursor-pointer text-left"
                >
                  Crown &amp; Stuffed Crust
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleLink('deals')}
                  className="hover:text-amber-400 transition-colors cursor-pointer text-left"
                >
                  24-Hour Mega Deals
                </button>
              </li>
            </ul>
          </div>

          {/* Opening Hours */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">Kitchen Hours</h4>
            <div className="bg-neutral-900/70 border border-neutral-800 p-3.5 rounded-xl space-y-2">
              <div className="flex items-center gap-2 text-neutral-200 font-semibold">
                <Clock className="w-4 h-4 text-amber-500" />
                <span>Monday – Sunday</span>
              </div>
              <div className="text-amber-400 font-mono text-sm font-bold pl-6">
                12:00 PM – 2:00 AM
              </div>
              <p className="text-[11px] text-neutral-500 pl-6">
                Open late 7 days a week for night delivery
              </p>
            </div>
          </div>

          {/* Contact Details */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">Location &amp; Delivery</h4>
            <ul className="space-y-2.5">
              <li className="flex items-start gap-2 text-neutral-300">
                <MapPin className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                <span>{RESTAURANT_INFO.address}</span>
              </li>
              <li className="flex items-center gap-2 text-neutral-300">
                <Phone className="w-4 h-4 text-amber-500 shrink-0" />
                <a href={`tel:${RESTAURANT_INFO.phone}`} className="hover:text-white font-mono">
                  {RESTAURANT_INFO.phone}
                </a>
              </li>
              <li className="flex items-center gap-2 text-neutral-300">
                <Bike className="w-4 h-4 text-amber-500 shrink-0" />
                <span>Home Delivery Available Citywide</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-neutral-850 flex flex-col sm:flex-row items-center justify-between gap-4 text-neutral-500 text-[11px]">
          <div>
            &copy; {new Date().getFullYear()} Champs Bites. All rights reserved. Made with love for authentic flavor.
          </div>
          <div className="flex items-center gap-6">
            <span>Halal Certified</span>
            <span>·</span>
            <span>Cash on Delivery</span>
            <span>·</span>
            <button
              onClick={scrollToTop}
              className="flex items-center gap-1 text-neutral-400 hover:text-white transition-colors cursor-pointer"
            >
              <span>Back to Top</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
