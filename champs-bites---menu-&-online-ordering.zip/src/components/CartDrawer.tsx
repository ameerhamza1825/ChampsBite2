import { useState, useId } from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag, MessageCircle, Bike, Store, ArrowRight, ShieldCheck } from 'lucide-react';
import { CartItem, OrderCustomerInfo, PlacedOrder } from '../types';
import { RESTAURANT_INFO } from '../data/menuData';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (cartId: string, delta: number) => void;
  onRemoveItem: (cartId: string) => void;
  onClearCart: () => void;
  onOrderPlaced: (order: PlacedOrder) => void;
}

export function CartDrawer({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onOrderPlaced,
}: CartDrawerProps) {
  const nameId = useId();
  const phoneId = useId();
  const addressId = useId();
  const notesId = useId();

  const [orderType, setOrderType] = useState<'delivery' | 'pickup'>('delivery');
  const [customer, setCustomer] = useState<OrderCustomerInfo>({
    name: '',
    phone: '',
    address: '',
    notes: '',
    orderType: 'delivery',
  });
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const subtotal = items.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);
  const isFreeDelivery = subtotal >= RESTAURANT_INFO.freeDeliveryThreshold || orderType === 'pickup';
  const deliveryFee = orderType === 'pickup' ? 0 : isFreeDelivery ? 0 : RESTAURANT_INFO.deliveryFee;
  const total = subtotal + deliveryFee;

  const amountNeededForFreeDelivery = Math.max(0, RESTAURANT_INFO.freeDeliveryThreshold - subtotal);
  const freeDeliveryProgress = Math.min(100, (subtotal / RESTAURANT_INFO.freeDeliveryThreshold) * 100);

  const validateForm = (): boolean => {
    if (!customer.name.trim()) {
      setErrorMsg('Please enter your full name');
      return false;
    }
    if (!customer.phone.trim() || customer.phone.length < 8) {
      setErrorMsg('Please provide a valid phone number for delivery confirmation');
      return false;
    }
    if (orderType === 'delivery' && !customer.address.trim()) {
      setErrorMsg('Please provide your complete street address for home delivery');
      return false;
    }
    setErrorMsg('');
    return true;
  };

  const generateWhatsAppMessage = (): string => {
    let msg = `*🍕 NEW ORDER - CHAMPS BITES*\n`;
    msg += `-------------------------------\n`;
    msg += `*Order Type:* ${orderType === 'delivery' ? 'Home Delivery 🛵' : 'Self Pickup 🏬'}\n`;
    msg += `*Customer:* ${customer.name}\n`;
    msg += `*Phone:* ${customer.phone}\n`;
    if (orderType === 'delivery') {
      msg += `*Address:* ${customer.address}\n`;
    }
    if (customer.notes && customer.notes.trim()) {
      msg += `*Special Note:* ${customer.notes.trim()}\n`;
    }
    msg += `-------------------------------\n`;
    msg += `*ORDER ITEMS:*\n`;

    items.forEach((item, index) => {
      msg += `${index + 1}. *${item.name}* x ${item.quantity}\n`;
      if (item.sizeLabel) msg += `   - Size: ${item.sizeLabel}\n`;
      if (item.crust) msg += `   - Crust: ${item.crust}\n`;
      if (item.addons && item.addons.length > 0) {
        msg += `   - Add-ons: ${item.addons.map((a) => a.name).join(', ')}\n`;
      }
      if (item.specialInstructions) {
        msg += `   - Note: ${item.specialInstructions}\n`;
      }
      msg += `   - Price: Rs. ${(item.unitPrice * item.quantity).toLocaleString()}\n\n`;
    });

    msg += `-------------------------------\n`;
    msg += `*Subtotal:* Rs. ${subtotal.toLocaleString()}\n`;
    msg += `*Delivery Fee:* ${deliveryFee === 0 ? 'FREE' : `Rs. ${deliveryFee}`}\n`;
    msg += `*Grand Total:* Rs. ${total.toLocaleString()}\n`;
    msg += `*Payment:* Cash on Delivery / Delivery Rider\n`;
    msg += `-------------------------------\n`;
    msg += `Please confirm my order and share estimated delivery time. Thank you!`;

    return msg;
  };

  const handleWhatsAppOrder = () => {
    if (!validateForm()) return;

    const message = generateWhatsAppMessage();
    const url = `https://wa.me/${RESTAURANT_INFO.whatsappRaw}?text=${encodeURIComponent(message)}`;

    // Create record
    const placedOrder: PlacedOrder = {
      orderId: `CB-${Math.floor(1000 + Math.random() * 9000)}`,
      date: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      items: [...items],
      subtotal,
      deliveryFee,
      total,
      customer: { ...customer, orderType },
      status: 'Received',
      estimatedMinutes: 35,
    };

    window.open(url, '_blank', 'noopener,noreferrer');
    onOrderPlaced(placedOrder);
    onClearCart();
    onClose();
  };

  const handleCashOnDeliveryConfirm = () => {
    if (!validateForm()) return;

    const placedOrder: PlacedOrder = {
      orderId: `CB-${Math.floor(1000 + Math.random() * 9000)}`,
      date: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      items: [...items],
      subtotal,
      deliveryFee,
      total,
      customer: { ...customer, orderType },
      status: 'Received',
      estimatedMinutes: 35,
    };

    onOrderPlaced(placedOrder);
    onClearCart();
    onClose();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="cart-drawer-title"
      className="fixed inset-0 z-50 overflow-hidden bg-black/70 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div className="absolute inset-0" onClick={onClose} />

      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-neutral-900 border-l border-neutral-800 shadow-2xl flex flex-col relative z-10">
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-neutral-800 flex items-center justify-between bg-neutral-950">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-amber-500" />
              <h2 id="cart-drawer-title" className="font-extrabold text-base sm:text-lg text-white font-display">
                Your Order Bag
              </h2>
              <span className="text-xs bg-neutral-800 text-neutral-300 font-mono px-2 py-0.5 rounded-full">
                {items.reduce((s, i) => s + i.quantity, 0)} items
              </span>
            </div>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close dialog"
              className="p-1.5 text-neutral-400 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Delivery Type Selector */}
          <div className="px-5 pt-4 pb-2 bg-neutral-900 border-b border-neutral-800/80">
            <div className="grid grid-cols-2 gap-2 bg-neutral-950 p-1 rounded-xl border border-neutral-800 text-xs font-semibold">
              <button
                type="button"
                onClick={() => setOrderType('delivery')}
                className={`py-2 rounded-lg flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                  orderType === 'delivery'
                    ? 'bg-amber-500 text-neutral-950 font-bold shadow-sm'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                <Bike className="w-4 h-4" />
                <span>Home Delivery</span>
              </button>

              <button
                type="button"
                onClick={() => setOrderType('pickup')}
                className={`py-2 rounded-lg flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                  orderType === 'pickup'
                    ? 'bg-amber-500 text-neutral-950 font-bold shadow-sm'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                <Store className="w-4 h-4" />
                <span>Takeaway / Pickup</span>
              </button>
            </div>

            {/* Free Delivery Meter */}
            {orderType === 'delivery' && (
              <div className="mt-3 text-xs">
                <div className="flex justify-between items-center text-neutral-400 mb-1">
                  {amountNeededForFreeDelivery > 0 ? (
                    <span>
                      Add <strong className="text-amber-400 font-mono">Rs. {amountNeededForFreeDelivery.toLocaleString()}</strong> more for FREE delivery
                    </span>
                  ) : (
                    <span className="text-emerald-400 font-semibold flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5" /> Free Citywide Delivery Unlocked!
                    </span>
                  )}
                  <span className="text-[11px] font-mono text-neutral-500">
                    {Math.round(freeDeliveryProgress)}%
                  </span>
                </div>
                <div className="w-full h-1.5 bg-neutral-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-amber-500 transition-all duration-300"
                    style={{ width: `${freeDeliveryProgress}%` }}
                  />
                </div>
              </div>
            )}
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3">
            {items.length === 0 ? (
              <div className="text-center py-16 text-neutral-500">
                <ShoppingBag className="w-12 h-12 mx-auto mb-3 text-neutral-700 stroke-1" />
                <p className="text-sm font-semibold text-neutral-400">Your bag is empty</p>
                <p className="text-xs text-neutral-500 mt-1 max-w-xs mx-auto">
                  Browse our pizzas, crispy burgers, or special value deals to get started.
                </p>
              </div>
            ) : (
              items.map((item) => (
                <div
                  key={item.cartId}
                  className="bg-neutral-950/80 border border-neutral-800 rounded-xl p-3 flex gap-3 items-start hover:border-neutral-700 transition-colors"
                >
                  <img
                    src={item.img}
                    alt={item.name}
                    className="w-14 h-14 rounded-lg object-cover bg-neutral-900 shrink-0"
                    onError={(e) => {
                      (e.target as HTMLElement).style.display = 'none';
                    }}
                  />

                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-1">
                      <h4 className="font-bold text-xs sm:text-sm text-white truncate">
                        {item.name}
                      </h4>
                      <button
                        type="button"
                        onClick={() => onRemoveItem(item.cartId)}
                        className="text-neutral-500 hover:text-rose-400 p-1 -mr-1 transition-colors cursor-pointer"
                        title="Remove item"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Metadata tags */}
                    <div className="text-[11px] text-neutral-400 space-y-0.5 mt-0.5">
                      {item.sizeLabel && <div>Size: <span className="text-neutral-300">{item.sizeLabel}</span></div>}
                      {item.crust && <div>Crust: <span className="text-amber-400">{item.crust}</span></div>}
                      {item.addons && item.addons.length > 0 && (
                        <div>
                          Add-ons: <span className="text-neutral-300">{item.addons.map((a) => a.name).join(', ')}</span>
                        </div>
                      )}
                      {item.specialInstructions && (
                        <div className="italic text-neutral-500 truncate">
                          &ldquo;{item.specialInstructions}&rdquo;
                        </div>
                      )}
                    </div>

                    {/* Price and Stepper */}
                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-neutral-850">
                      <div className="text-xs font-bold text-amber-400 font-mono tabular-nums">
                        Rs. {(item.unitPrice * item.quantity).toLocaleString()}
                      </div>

                      <div className="flex items-center gap-1.5 bg-neutral-900 border border-neutral-800 rounded-lg p-0.5">
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(item.cartId, -1)}
                          className="w-6 h-6 flex items-center justify-center text-neutral-400 hover:text-white rounded transition-colors cursor-pointer"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="w-6 text-center text-xs font-bold font-mono tabular-nums text-white">
                          {item.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(item.cartId, 1)}
                          className="w-6 h-6 flex items-center justify-center text-neutral-400 hover:text-white rounded transition-colors cursor-pointer"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}

            {/* Customer Details Form */}
            {items.length > 0 && (
              <div className="mt-5 pt-4 border-t border-neutral-800 space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-300">
                  Customer &amp; Delivery Details
                </h4>

                {errorMsg && (
                  <div className="p-2.5 rounded-lg bg-rose-950/80 border border-rose-800/80 text-rose-300 text-xs font-medium">
                    {errorMsg}
                  </div>
                )}

                <div className="space-y-2 text-xs">
                  <div>
                    <label htmlFor={nameId} className="text-neutral-400 block mb-1">Your Full Name *</label>
                    <input
                      id={nameId}
                      type="text"
                      placeholder="e.g. Hamza Butt"
                      value={customer.name}
                      onChange={(e) => setCustomer({ ...customer, name: e.target.value })}
                      className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-500 rounded-lg px-3 py-2 text-xs text-white placeholder-neutral-500 outline-none"
                    />
                  </div>

                  <div>
                    <label htmlFor={phoneId} className="text-neutral-400 block mb-1">Contact Phone Number *</label>
                    <input
                      id={phoneId}
                      type="tel"
                      placeholder="e.g. 0300-1234567"
                      value={customer.phone}
                      onChange={(e) => setCustomer({ ...customer, phone: e.target.value })}
                      className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-500 rounded-lg px-3 py-2 text-xs text-white placeholder-neutral-500 outline-none"
                    />
                  </div>

                  {orderType === 'delivery' && (
                    <div>
                      <label htmlFor={addressId} className="text-neutral-400 block mb-1">Complete Delivery Address *</label>
                      <textarea
                        id={addressId}
                        rows={2}
                        placeholder="House / Flat #, Street, Area / Sector, City"
                        value={customer.address}
                        onChange={(e) => setCustomer({ ...customer, address: e.target.value })}
                        className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-500 rounded-lg px-3 py-2 text-xs text-white placeholder-neutral-500 outline-none resize-none"
                      />
                    </div>
                  )}

                  <div>
                    <label htmlFor={notesId} className="text-neutral-400 block mb-1">Order Notes (Optional)</label>
                    <input
                      id={notesId}
                      type="text"
                      placeholder="e.g. Ring bell twice, extra ketchup"
                      value={customer.notes}
                      onChange={(e) => setCustomer({ ...customer, notes: e.target.value })}
                      className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-500 rounded-lg px-3 py-2 text-xs text-white placeholder-neutral-500 outline-none"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Footer: Summary & Checkout Buttons */}
          {items.length > 0 && (
            <div className="p-4 sm:p-5 border-t border-neutral-800 bg-neutral-950 space-y-3">
              {/* Totals */}
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between text-neutral-400">
                  <span>Subtotal</span>
                  <span className="font-mono tabular-nums text-white">Rs. {subtotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-neutral-400">
                  <span>Delivery Fee</span>
                  <span className="font-mono tabular-nums">
                    {deliveryFee === 0 ? (
                      <span className="text-emerald-400 font-bold">FREE</span>
                    ) : (
                      `Rs. ${deliveryFee}`
                    )}
                  </span>
                </div>
                <div className="flex justify-between text-sm sm:text-base font-extrabold text-white pt-2 border-t border-neutral-800">
                  <span>Total Payable</span>
                  <span className="text-amber-400 font-mono tabular-nums">Rs. {total.toLocaleString()}</span>
                </div>
                <p className="text-[11px] text-neutral-500 text-right">Cash on Delivery / Card on Doorstep</p>
              </div>

              {/* Checkout CTAs */}
              <div className="space-y-2 pt-1">
                <button
                  type="button"
                  onClick={handleWhatsAppOrder}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 active:scale-95 cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Order via WhatsApp (Instant)</span>
                </button>

                <button
                  type="button"
                  onClick={handleCashOnDeliveryConfirm}
                  className="w-full py-2.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 hover:text-white font-semibold text-xs rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <span>Confirm Cash on Delivery Receipt</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
