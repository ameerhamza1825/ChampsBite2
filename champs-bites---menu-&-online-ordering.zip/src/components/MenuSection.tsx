import React, { useState, useMemo } from 'react';
import { Search, X, UtensilsCrossed, Flame, Sparkles } from 'lucide-react';
import { MenuItem, MenuCategory, PizzaSize } from '../types';
import { MENU_ITEMS } from '../data/menuData';
import { MenuCard } from './MenuCard';

interface MenuSectionProps {
  onAddToCart: (item: MenuItem, size?: PizzaSize) => void;
  onCustomize: (item: MenuItem) => void;
}

export function MenuSection({ onAddToCart, onCustomize }: MenuSectionProps) {
  const [activeCategory, setActiveCategory] = useState<MenuCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [dietaryFilter, setDietaryFilter] = useState<'all' | 'spicy' | 'veg'>('all');
  const [visibleCount, setVisibleCount] = useState(16);

  const categories: { id: MenuCategory; label: string; count: number }[] = [
    { id: 'all', label: 'All Items', count: MENU_ITEMS.length },
    { id: 'pizza', label: 'Pizzas', count: MENU_ITEMS.filter((i) => i.cat === 'pizza').length },
    { id: 'burger', label: 'Burgers', count: MENU_ITEMS.filter((i) => i.cat === 'burger').length },
    { id: 'sandwich', label: 'Sandwiches & Pasta', count: MENU_ITEMS.filter((i) => i.cat === 'sandwich').length },
    { id: 'wrap', label: 'Wraps & Shawarma', count: MENU_ITEMS.filter((i) => i.cat === 'wrap').length },
    { id: 'starter', label: 'Starters & Sides', count: MENU_ITEMS.filter((i) => i.cat === 'starter').length },
    { id: 'dessert', label: 'Desserts & Drinks', count: MENU_ITEMS.filter((i) => i.cat === 'dessert').length },
  ];

  const filteredItems = useMemo(() => {
    return MENU_ITEMS.filter((item) => {
      // Category filter
      if (activeCategory !== 'all' && item.cat !== activeCategory) {
        return false;
      }
      // Dietary filter
      if (dietaryFilter === 'spicy' && !item.isSpicy) return false;
      if (dietaryFilter === 'veg' && !item.isVegetarian) return false;

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = item.name.toLowerCase().includes(q);
        const matchesDesc = item.desc.toLowerCase().includes(q);
        return matchesName || matchesDesc;
      }
      return true;
    });
  }, [activeCategory, searchQuery, dietaryFilter]);

  // Reset visibleCount when filters change
  const handleCategoryChange = (cat: MenuCategory) => {
    setActiveCategory(cat);
    setVisibleCount(16);
  };

  const visibleItems = useMemo(() => {
    // When viewing a specific category (which has <= 15 items), show all.
    // When viewing 'all' with 56 items, paginate to 16 for ultra fast rendering.
    if (activeCategory !== 'all' || searchQuery.trim()) {
      return filteredItems;
    }
    return filteredItems.slice(0, visibleCount);
  }, [filteredItems, activeCategory, searchQuery, visibleCount]);

  return (
    <section id="menu" className="py-12 md:py-16 bg-neutral-950 min-h-[60vh]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-8">
          <div className="text-xs uppercase font-bold tracking-widest text-amber-500 mb-2">
            Freshly Made To Order
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold font-display text-white tracking-tight">
            Our Complete Menu
          </h2>
          <p className="text-neutral-400 text-xs sm:text-sm mt-2 leading-relaxed">
            Select sizes, customize crusts, add dips and order directly via WhatsApp or Cash on Delivery.
          </p>
        </div>

        {/* Controls: Search + Categories */}
        <div className="space-y-5 mb-10">
          {/* Top row: Search and Dietary filters */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 max-w-4xl mx-auto">
            {/* Search Input */}
            <div className="relative w-full sm:max-w-md">
              <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                placeholder="Search pizzas, burgers, fries, pasta..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-neutral-900 border border-neutral-800 focus:border-amber-500 text-white placeholder-neutral-500 pl-10 pr-9 py-2.5 rounded-xl text-sm outline-none transition-colors"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Quick dietary toggles */}
            <div className="flex items-center gap-1.5 bg-neutral-900 border border-neutral-800 p-1 rounded-xl text-xs">
              <button
                type="button"
                onClick={() => setDietaryFilter('all')}
                className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                  dietaryFilter === 'all' ? 'bg-neutral-800 text-white font-semibold' : 'text-neutral-400 hover:text-white'
                }`}
              >
                All
              </button>
              <button
                type="button"
                onClick={() => setDietaryFilter(dietaryFilter === 'spicy' ? 'all' : 'spicy')}
                className={`flex items-center gap-1 px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                  dietaryFilter === 'spicy' ? 'bg-rose-950/80 text-rose-300 font-semibold border border-rose-800/50' : 'text-neutral-400 hover:text-white'
                }`}
              >
                <Flame className="w-3.5 h-3.5 text-rose-400" />
                <span>Spicy</span>
              </button>
              <button
                type="button"
                onClick={() => setDietaryFilter(dietaryFilter === 'veg' ? 'all' : 'veg')}
                className={`flex items-center gap-1 px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                  dietaryFilter === 'veg' ? 'bg-emerald-950/80 text-emerald-300 font-semibold border border-emerald-800/50' : 'text-neutral-400 hover:text-white'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                <span>Veg</span>
              </button>
            </div>
          </div>

          {/* Category Tabs (Interactive Segmented Bar) */}
          <div className="flex items-center justify-start sm:justify-center gap-2 overflow-x-auto pb-2 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => handleCategoryChange(cat.id)}
                className={`px-4 py-2 text-xs font-semibold rounded-xl whitespace-nowrap transition-all cursor-pointer ${
                  activeCategory === cat.id
                    ? 'bg-amber-500 text-neutral-950 shadow-md shadow-amber-500/20'
                    : 'bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white hover:border-neutral-700'
                }`}
              >
                <span>{cat.label}</span>
                <span className={`ml-1.5 text-[10px] font-mono tabular-nums ${activeCategory === cat.id ? 'text-neutral-950/80' : 'text-neutral-500'}`}>
                  ({cat.count})
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Results metadata bar */}
        <div className="flex items-center justify-between text-xs text-neutral-400 mb-6 px-1">
          <div>
            Showing <span className="text-white font-semibold font-mono tabular-nums">{visibleItems.length}</span> of <span className="text-white font-semibold font-mono tabular-nums">{filteredItems.length}</span> items
            {searchQuery && (
              <span>
                {' '}for &ldquo;<strong className="text-amber-400">{searchQuery}</strong>&rdquo;
              </span>
            )}
          </div>
          {(searchQuery || dietaryFilter !== 'all' || activeCategory !== 'all') && (
            <button
              onClick={() => {
                setSearchQuery('');
                setDietaryFilter('all');
                handleCategoryChange('all');
              }}
              className="text-amber-400 hover:underline cursor-pointer"
            >
              Reset filters
            </button>
          )}
        </div>

        {/* Items Grid */}
        {filteredItems.length > 0 ? (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
              {visibleItems.map((item) => (
                <MenuCard
                  key={item.id}
                  item={item}
                  onAddToCart={onAddToCart}
                  onCustomize={onCustomize}
                />
              ))}
            </div>

            {/* Load More Button for 'all' tab if more items available */}
            {visibleItems.length < filteredItems.length && (
              <div className="mt-10 text-center">
                <button
                  type="button"
                  onClick={() => setVisibleCount((prev) => prev + 16)}
                  className="px-6 py-3 bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer hover:border-amber-500/50 shadow-md"
                >
                  Load More Items ({filteredItems.length - visibleItems.length} remaining)
                </button>
              </div>
            )}
          </>
        ) : (
          <div className="text-center py-20 bg-neutral-900/50 border border-neutral-800 rounded-2xl p-8">
            <UtensilsCrossed className="w-12 h-12 text-neutral-600 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-white mb-1">No items found</h3>
            <p className="text-sm text-neutral-400 max-w-sm mx-auto mb-4">
              We couldn&apos;t find anything matching your search. Try searching for &ldquo;pizza&rdquo;, &ldquo;burger&rdquo;, or &ldquo;wings&rdquo;.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setDietaryFilter('all');
                setActiveCategory('all');
              }}
              className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
            >
              Clear Search & Show All
            </button>
          </div>
        )}
      </div>
    </section>
  );
}
