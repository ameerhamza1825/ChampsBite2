import React, { useState } from 'react';
import { Plus, SlidersHorizontal, Flame, Sparkles } from 'lucide-react';
import { MenuItem, PizzaSize } from '../types';
import { SIZE_LABELS } from '../data/menuData';

interface MenuCardProps {
  item: MenuItem;
  onAddToCart: (item: MenuItem, size?: PizzaSize) => void;
  onCustomize: (item: MenuItem) => void;
}

export function MenuCard({ item, onAddToCart, onCustomize }: MenuCardProps) {
  const [selectedSize, setSelectedSize] = useState<PizzaSize>('M');
  const [imgLoaded, setImgLoaded] = useState(false);
  const hasSizes = !!item.sizes;

  const currentPrice = hasSizes ? item.sizes![selectedSize] : item.price || 0;

  return (
    <div className="bg-neutral-900 border border-neutral-800 rounded-xl overflow-hidden flex flex-col hover:border-amber-500/40 hover:shadow-xl hover:shadow-amber-500/5 transition-all duration-300 group">
      {/* Image container */}
      <div className="relative aspect-[16/10] bg-neutral-950 overflow-hidden">
        {!imgLoaded && (
          <div className="absolute inset-0 bg-neutral-900 animate-pulse flex items-center justify-center text-neutral-700 text-xs font-mono">
            Champs Bites
          </div>
        )}
        <img
          src={item.img}
          alt={item.name}
          loading="lazy"
          decoding="async"
          onLoad={() => setImgLoaded(true)}
          referrerPolicy="no-referrer"
          className={`w-full h-full object-cover transition-all duration-500 group-hover:scale-105 ${
            imgLoaded ? 'opacity-100' : 'opacity-0'
          }`}
          onError={(e) => {
            (e.target as HTMLElement).style.display = 'none';
          }}
        />

        {/* Clean text badge (single text tag, non-candy) */}
        {item.badge && (
          <div className="absolute top-2.5 left-2.5">
            <span
              className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                item.badgeType === 'hot'
                  ? 'bg-rose-950/90 text-rose-300 border border-rose-800/60'
                  : item.badgeType === 'new'
                  ? 'bg-emerald-950/90 text-emerald-300 border border-emerald-800/60'
                  : 'bg-amber-950/90 text-amber-300 border border-amber-800/60'
              }`}
            >
              {item.badge}
            </span>
          </div>
        )}

        {/* Dietary / Spice indicator */}
        <div className="absolute top-2.5 right-2.5 flex items-center gap-1">
          {item.isSpicy && (
            <span className="bg-neutral-950/80 p-1 rounded text-rose-400" title="Spicy">
              <Flame className="w-3.5 h-3.5" />
            </span>
          )}
          {item.isVegetarian && (
            <span className="bg-neutral-950/80 p-1 rounded text-emerald-400" title="Vegetarian">
              <Sparkles className="w-3.5 h-3.5" />
            </span>
          )}
        </div>
      </div>

      {/* Body */}
      <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
        <div>
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-bold text-sm sm:text-base text-white group-hover:text-amber-400 transition-colors">
              {item.name}
            </h3>
          </div>
          <p className="text-xs text-neutral-400 line-clamp-2 mt-1 leading-relaxed">
            {item.desc}
          </p>
        </div>

        {/* Size Selector for Pizzas */}
        {hasSizes && (
          <div className="pt-1">
            <label className="text-[10px] uppercase font-semibold text-neutral-400 mb-1 block">
              Select Size
            </label>
            <div className="grid grid-cols-4 gap-1 p-0.5 bg-neutral-950 rounded-lg border border-neutral-800">
              {(['S', 'M', 'L', 'XL'] as PizzaSize[]).map((size) => (
                <button
                  key={size}
                  type="button"
                  onClick={() => setSelectedSize(size)}
                  className={`py-1 text-[11px] font-medium rounded transition-colors cursor-pointer ${
                    selectedSize === size
                      ? 'bg-amber-500 text-neutral-950 font-bold'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                  title={`${SIZE_LABELS[size]} - Rs. ${item.sizes![size]}`}
                >
                  {size}
                </button>
              ))}
            </div>
            <div className="text-[11px] text-neutral-400 mt-1 flex justify-between">
              <span>{SIZE_LABELS[selectedSize]}</span>
            </div>
          </div>
        )}

        {/* Price & Action Row */}
        <div className="pt-2 border-t border-neutral-800/80 flex items-center justify-between gap-2">
          <div>
            {hasSizes && <span className="text-[10px] text-neutral-400 block -mb-0.5">Price</span>}
            <div className="text-base sm:text-lg font-extrabold text-amber-400 font-mono tabular-nums">
              Rs. {currentPrice.toLocaleString()}
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Quick customize button if pizza or burger */}
            {(hasSizes || item.cat === 'burger' || item.cat === 'sandwich') && (
              <button
                type="button"
                onClick={() => onCustomize(item)}
                className="p-2 text-neutral-400 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded-lg text-xs transition-colors cursor-pointer"
                title="Customize crust & toppings"
                aria-label="Customize"
              >
                <SlidersHorizontal className="w-3.5 h-3.5" />
              </button>
            )}

            <button
              type="button"
              onClick={() => onAddToCart(item, hasSizes ? selectedSize : undefined)}
              className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs rounded-lg transition-all flex items-center gap-1 active:scale-95 cursor-pointer whitespace-nowrap"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
