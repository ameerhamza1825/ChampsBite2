import { Check, Flame, MessageCircle, Plus } from 'lucide-react';
import { DealItem } from '../types';
import { STARTER_DEALS, BURGER_DEALS, MEGA_DEALS, RESTAURANT_INFO } from '../data/menuData';

interface DealsSectionProps {
  onAddDealToCart: (deal: DealItem) => void;
}

export function DealsSection({ onAddDealToCart }: DealsSectionProps) {
  const renderDealCard = (deal: DealItem) => {
    return (
      <div
        key={deal.id}
        className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 flex flex-col justify-between hover:border-amber-500/50 hover:shadow-xl hover:shadow-amber-500/5 transition-all group relative overflow-hidden"
      >
        {/* Subtle accent border on top */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-500 to-red-500" />

        <div>
          {/* Header row */}
          <div className="flex items-start justify-between gap-2 mb-3">
            <h3 className="font-bold text-base text-white group-hover:text-amber-400 transition-colors">
              {deal.name}
            </h3>
            {deal.tag && (
              <span className="text-[11px] font-bold text-amber-400 bg-amber-950/60 border border-amber-800/40 px-2 py-0.5 rounded shrink-0">
                {deal.tag}
              </span>
            )}
          </div>

          {/* Items list */}
          <ul className="space-y-1.5 mb-5">
            {deal.items.map((item, idx) => (
              <li key={idx} className="flex items-start gap-2 text-xs text-neutral-300">
                <Check className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Footer: Price + Actions */}
        <div className="pt-3 border-t border-neutral-800 flex items-end justify-between gap-3">
          <div>
            <div className="flex items-baseline gap-2">
              <span className="text-xl font-extrabold text-amber-400 font-mono tabular-nums">
                Rs. {deal.price.toLocaleString()}
              </span>
              {deal.oldPrice && (
                <span className="text-xs text-neutral-500 line-through font-mono tabular-nums">
                  Rs. {deal.oldPrice.toLocaleString()}
                </span>
              )}
            </div>
            {deal.saveAmount && (
              <span className="text-[11px] text-emerald-400 font-semibold block mt-0.5">
                Save Rs. {deal.saveAmount}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <a
              href={`https://wa.me/${RESTAURANT_INFO.whatsappRaw}?text=${encodeURIComponent(
                `Hi Champs Bites! I would like to order the "${deal.name}" (Rs. ${deal.price}).`
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white rounded-lg transition-colors cursor-pointer"
              title="Order on WhatsApp"
            >
              <MessageCircle className="w-4 h-4 text-emerald-400" />
            </a>

            <button
              type="button"
              onClick={() => onAddDealToCart(deal)}
              className="px-3 py-2 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs rounded-lg transition-all flex items-center gap-1 active:scale-95 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Deal</span>
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <section id="deals" className="py-16 md:py-20 bg-neutral-950/70 border-t border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 text-xs uppercase font-bold tracking-widest text-amber-500 mb-2">
            <Flame className="w-4 h-4 text-amber-500" />
            <span>Unbeatable Savings</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold font-display text-white tracking-tight">
            Today&apos;s Special Deals &amp; Combos
          </h2>
          <p className="text-neutral-400 text-sm mt-3 leading-relaxed">
            Stack up the savings with our curated combo boxes, burger value bundles, and 24-hour mega family feasts.
          </p>
        </div>

        {/* 1. Starter Deals */}
        <div className="mb-14">
          <div className="flex items-center justify-between border-b border-neutral-800 pb-3 mb-6">
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <span>Starter &amp; Snack Deals</span>
                <span className="text-xs text-amber-400 font-mono font-normal">({STARTER_DEALS.length})</span>
              </h3>
              <p className="text-xs text-neutral-400">Wing platters, crispy spin rolls, loaded fries & dips</p>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {STARTER_DEALS.map(renderDealCard)}
          </div>
        </div>

        {/* 2. Burger Value Deals */}
        <div className="mb-14">
          <div className="flex items-center justify-between border-b border-neutral-800 pb-3 mb-6">
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <span>Burger Value Deals</span>
                <span className="text-xs text-amber-400 font-mono font-normal">({BURGER_DEALS.length})</span>
              </h3>
              <p className="text-xs text-neutral-400">Crispy zinger, jumbo & double patty combos with fries and chilled soda</p>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {BURGER_DEALS.map(renderDealCard)}
          </div>
        </div>

        {/* 3. 24 Hours Mega Deals */}
        <div>
          <div className="flex items-center justify-between border-b border-neutral-800 pb-3 mb-6">
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <span>24 Hours Mega Deals</span>
                <span className="text-xs text-amber-400 font-mono font-normal">({MEGA_DEALS.length})</span>
              </h3>
              <p className="text-xs text-neutral-400">Family pizza feasts, platter combos, wings & large soft drinks</p>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {MEGA_DEALS.map(renderDealCard)}
          </div>
        </div>
      </div>
    </section>
  );
}
