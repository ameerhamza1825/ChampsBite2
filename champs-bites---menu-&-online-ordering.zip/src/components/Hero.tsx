import { ArrowRight, Flame, Clock, Sparkles } from 'lucide-react';
import { ASSETS, RESTAURANT_INFO } from '../data/menuData';

interface HeroProps {
  onExploreMenu: () => void;
  onExploreDeals: () => void;
}

export function Hero({ onExploreMenu, onExploreDeals }: HeroProps) {
  return (
    <section className="relative overflow-hidden bg-neutral-950 pt-8 pb-16 md:pt-16 md:pb-24 border-b border-neutral-800">
      {/* Background glow subtle gradient */}
      <div className="absolute top-1/4 right-0 w-96 h-96 bg-amber-600/10 rounded-full blur-3xl pointer-events-none -mr-20" />
      <div className="absolute bottom-0 left-1/4 w-80 h-80 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          {/* Left Text */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-500">
              <Sparkles className="w-4 h-4" />
              <span>Finest Fast Food in Town</span>
              <span className="text-neutral-600">·</span>
              <span className="text-neutral-400">Halal Certified</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold font-display tracking-tight text-white leading-[1.1] text-balance">
              Taste the <span className="text-amber-500 underline decoration-amber-500/40 decoration-wavy underline-offset-8">Magic</span> in Every Single Bite.
            </h1>

            <p className="text-neutral-400 text-base sm:text-lg max-w-xl mx-auto lg:mx-0 leading-relaxed">
              Hand-stretched stone baked crusts, authentic Pakistani spiced tikka and malai boti, crunchy zinger fillets, and molten cheese stuffed crusts.
            </p>

            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-2">
              <button
                onClick={onExploreMenu}
                className="px-6 py-3.5 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-sm tracking-wide rounded-xl shadow-lg shadow-amber-500/20 hover:shadow-amber-500/30 transition-all flex items-center gap-2 active:scale-95 cursor-pointer"
              >
                <span>Explore Full Menu</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onExploreDeals}
                className="px-6 py-3.5 bg-neutral-900 hover:bg-neutral-800 text-white font-semibold text-sm border border-neutral-700/80 rounded-xl transition-all flex items-center gap-2 active:scale-95 cursor-pointer"
              >
                <Flame className="w-4 h-4 text-amber-500" />
                <span>Today&apos;s Special Deals</span>
              </button>
            </div>

            {/* Unboxed Metadata Highlights (Zero-Pill Discipline) */}
            <div className="pt-6 border-t border-neutral-850 flex flex-wrap items-center justify-center lg:justify-start gap-y-2 gap-x-4 text-xs text-neutral-400">
              <div className="flex items-center gap-1.5 text-neutral-300">
                <Clock className="w-3.5 h-3.5 text-amber-500" />
                <span>35–45 Min Hot Delivery</span>
              </div>
              <span className="text-neutral-700" aria-hidden="true">·</span>
              <div>Free Delivery Over Rs. {RESTAURANT_INFO.freeDeliveryThreshold.toLocaleString()}</div>
              <span className="text-neutral-700" aria-hidden="true">·</span>
              <div>100% Real Mozzarella</div>
              <span className="text-neutral-700" aria-hidden="true">·</span>
              <div className="text-amber-400 font-medium">Cash on Delivery & WhatsApp Checkout</div>
            </div>
          </div>

          {/* Right Hero Visual Showcase */}
          <div className="lg:col-span-5 relative flex justify-center">
            <div className="relative w-full max-w-md aspect-square rounded-2xl overflow-hidden border border-neutral-800 shadow-2xl group">
              <img
                src={ASSETS.heroPizza}
                alt="Champs Bites Signature Pizza"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                onError={(e) => {
                  // Fallback container styling
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/80 via-transparent to-transparent pointer-events-none" />

              {/* Floating feature label */}
              <div className="absolute bottom-4 left-4 right-4 bg-neutral-900/90 backdrop-blur-md border border-neutral-700/60 p-3.5 rounded-xl flex items-center justify-between gap-3">
                <div>
                  <div className="text-xs uppercase tracking-wider text-amber-500 font-bold">Featured Signature</div>
                  <div className="text-sm font-bold text-white">Champs Special Pizza</div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] text-neutral-400">Starting from</div>
                  <div className="text-sm font-extrabold text-amber-400 font-mono tabular-nums">Rs. 550</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
