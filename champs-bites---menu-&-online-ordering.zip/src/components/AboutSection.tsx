import { Flame, Award, HeartHandshake, ShieldCheck } from 'lucide-react';
import { ASSETS } from '../data/menuData';

export function AboutSection() {
  const highlights = [
    {
      icon: Flame,
      title: 'Stone-Fired Crust',
      desc: 'Fermented for 24 hours to achieve an airy, bubbly crumb with a golden crunchy crust.',
    },
    {
      icon: Award,
      title: '100% Whole Milk Mozzarella',
      desc: 'No artificial cheese blends or substitutes. Pure dairy mozzarella for the ultimate cheese pull.',
    },
    {
      icon: HeartHandshake,
      title: 'Authentic Local Recipes',
      desc: 'Signature Pakistani spiced Chicken Tikka, creamy Malai Boti, and fiery Peri-Peri marinades.',
    },
    {
      icon: ShieldCheck,
      title: 'Thermal Hot Delivery',
      desc: 'Packed in heated thermal delivery bags to ensure piping hot food arrives at your door.',
    },
  ];

  return (
    <section id="about" className="py-16 md:py-24 bg-neutral-950 border-t border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Visual Grid */}
          <div className="lg:col-span-5 grid grid-cols-2 gap-4">
            <div className="space-y-4">
              <div className="rounded-xl overflow-hidden aspect-[4/5] border border-neutral-800 shadow-lg">
                <img
                  src={ASSETS.heroPizza}
                  alt="Freshly baked pizza"
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
              </div>
              <div className="bg-neutral-900 border border-neutral-800 p-4 rounded-xl text-center">
                <div className="text-2xl font-extrabold text-amber-400 font-mono tabular-nums">24 Hr</div>
                <div className="text-xs text-neutral-400 mt-0.5">Slow Fermented Dough</div>
              </div>
            </div>

            <div className="space-y-4 pt-6">
              <div className="bg-neutral-900 border border-neutral-800 p-4 rounded-xl text-center">
                <div className="text-2xl font-extrabold text-emerald-400 font-mono tabular-nums">100%</div>
                <div className="text-xs text-neutral-400 mt-0.5">Fresh Halal Chicken</div>
              </div>
              <div className="rounded-xl overflow-hidden aspect-[4/5] border border-neutral-800 shadow-lg">
                <img
                  src={ASSETS.burgerShowcase}
                  alt="Gourmet fast food burger"
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
              </div>
            </div>
          </div>

          {/* Text Content */}
          <div className="lg:col-span-7 space-y-6">
            <div className="text-xs font-bold uppercase tracking-wider text-amber-500">
              Our Passion for Flavor
            </div>

            <h2 className="text-3xl sm:text-4xl font-extrabold font-display text-white tracking-tight text-balance">
              Crafted with Precision. Baked with Passion.
            </h2>

            <p className="text-neutral-300 text-sm sm:text-base leading-relaxed">
              At <strong className="text-white">Champs Bites</strong>, we set out to redefine fast food comfort. Every pizza begins with our signature dough recipe, hand-stretched to order, smothered in rich tomato marinara, and topped generously with seasoned grilled chicken and bubbly mozzarella cheese.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              {highlights.map((h, idx) => {
                const Icon = h.icon;
                return (
                  <div key={idx} className="bg-neutral-900/60 border border-neutral-800/80 p-4 rounded-xl space-y-1.5">
                    <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
                      <Icon className="w-4 h-4 text-amber-500" />
                      <span>{h.title}</span>
                    </div>
                    <p className="text-xs text-neutral-400 leading-relaxed">{h.desc}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
