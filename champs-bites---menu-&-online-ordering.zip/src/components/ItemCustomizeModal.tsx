import { useState, useId } from 'react';
import { X, Plus, Minus, Check, Sparkles } from 'lucide-react';
import { MenuItem, PizzaSize, CartItem } from '../types';
import { CRUST_OPTIONS, ADDON_OPTIONS, SIZE_LABELS } from '../data/menuData';

interface ItemCustomizeModalProps {
  item: MenuItem | null;
  initialCrust?: 'classic' | 'cheese_stuffed' | 'kabab_stuffed';
  onClose: () => void;
  onAddToCart: (cartItem: CartItem) => void;
}

export function ItemCustomizeModal({
  item,
  initialCrust = 'classic',
  onClose,
  onAddToCart,
}: ItemCustomizeModalProps) {
  const instructionsId = useId();

  if (!item) return null;

  const hasSizes = !!item.sizes;
  const [selectedSize, setSelectedSize] = useState<PizzaSize>('M');
  const [selectedCrust, setSelectedCrust] = useState<'classic' | 'cheese_stuffed' | 'kabab_stuffed'>(
    initialCrust
  );
  const [selectedAddons, setSelectedAddons] = useState<string[]>([]);
  const [quantity, setQuantity] = useState(1);
  const [specialInstructions, setSpecialInstructions] = useState('');

  // Base price calculation
  const basePrice = hasSizes ? item.sizes![selectedSize] : item.price || 0;

  // Crust price
  const crustObj = CRUST_OPTIONS.find((c) => c.id === selectedCrust);
  const crustPrice = hasSizes && crustObj ? crustObj.price : 0;

  // Addons price
  const addonsTotal = selectedAddons.reduce((sum, addonId) => {
    const found = ADDON_OPTIONS.find((a) => a.id === addonId);
    return sum + (found ? found.price : 0);
  }, 0);

  const unitPrice = basePrice + crustPrice + addonsTotal;
  const totalPrice = unitPrice * quantity;

  const toggleAddon = (addonId: string) => {
    setSelectedAddons((prev) =>
      prev.includes(addonId) ? prev.filter((id) => id !== addonId) : [...prev, addonId]
    );
  };

  const handleAdd = () => {
    const resolvedAddons = selectedAddons
      .map((id) => ADDON_OPTIONS.find((a) => a.id === id))
      .filter(Boolean)
      .map((a) => ({ name: a!.name, price: a!.price }));

    const cartId = `${item.id}-${hasSizes ? selectedSize : 'std'}-${selectedCrust}-${selectedAddons.sort().join('_')}-${Date.now()}`;

    const newCartItem: CartItem = {
      cartId,
      menuId: item.id,
      name: item.name,
      cat: item.cat,
      selectedSize: hasSizes ? selectedSize : undefined,
      sizeLabel: hasSizes ? SIZE_LABELS[selectedSize] : undefined,
      crust: hasSizes && crustObj?.id !== 'classic' ? crustObj?.name : undefined,
      crustPrice: hasSizes ? crustPrice : 0,
      addons: resolvedAddons.length > 0 ? resolvedAddons : undefined,
      specialInstructions: specialInstructions.trim() || undefined,
      unitPrice,
      quantity,
      img: item.img,
    };

    onAddToCart(newCartItem);
    onClose();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="customize-item-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200"
    >
      <div className="relative w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-neutral-800 flex items-start justify-between gap-4 bg-neutral-950">
          <div>
            <div className="text-[11px] uppercase tracking-wider text-amber-500 font-bold">
              Customize Item
            </div>
            <h2 id="customize-item-title" className="text-lg sm:text-xl font-bold text-white mt-0.5">
              {item.name}
            </h2>
            <p className="text-xs text-neutral-400 mt-1 line-clamp-2">{item.desc}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close dialog"
            className="p-1.5 text-neutral-400 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors cursor-pointer shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-5 overflow-y-auto space-y-6 flex-1 text-xs sm:text-sm">
          {/* 1. Size Selection for Pizzas */}
          {hasSizes && (
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-neutral-300 block">
                1. Choose Size
              </label>
              <div className="grid grid-cols-2 gap-2">
                {(['S', 'M', 'L', 'XL'] as PizzaSize[]).map((size) => {
                  const isSelected = selectedSize === size;
                  return (
                    <button
                      key={size}
                      type="button"
                      onClick={() => setSelectedSize(size)}
                      className={`p-3 rounded-xl border text-left flex justify-between items-center transition-all cursor-pointer ${
                        isSelected
                          ? 'border-amber-500 bg-amber-950/20 text-white'
                          : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:border-neutral-700'
                      }`}
                    >
                      <div>
                        <div className="font-bold text-sm text-white">{SIZE_LABELS[size]}</div>
                        <div className="text-[11px] text-neutral-400 mt-0.5">
                          Rs. {item.sizes![size].toLocaleString()}
                        </div>
                      </div>
                      {isSelected && (
                        <div className="w-5 h-5 rounded-full bg-amber-500 flex items-center justify-center text-neutral-950">
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* 2. Crust Selection for Pizzas */}
          {hasSizes && (
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-neutral-300 flex items-center justify-between">
                <span>2. Choose Crust</span>
                <span className="text-[10px] text-amber-400 font-normal">Optional</span>
              </label>
              <div className="space-y-2">
                {CRUST_OPTIONS.map((crust) => {
                  const isSelected = selectedCrust === crust.id;
                  return (
                    <button
                      key={crust.id}
                      type="button"
                      onClick={() => setSelectedCrust(crust.id)}
                      className={`w-full p-3 rounded-xl border text-left flex items-start justify-between gap-3 transition-all cursor-pointer ${
                        isSelected
                          ? 'border-amber-500 bg-amber-950/20 text-white'
                          : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:border-neutral-700'
                      }`}
                    >
                      <div className="space-y-0.5">
                        <div className="font-bold text-sm text-white flex items-center gap-1.5">
                          <span>{crust.name}</span>
                          {crust.price > 0 && (
                            <span className="text-xs text-amber-400 font-mono font-semibold">
                              (+Rs. {crust.price})
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-neutral-400">{crust.description}</div>
                      </div>
                      {isSelected && (
                        <div className="w-5 h-5 rounded-full bg-amber-500 flex items-center justify-center text-neutral-950 shrink-0 mt-0.5">
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* 3. Add-on extras */}
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-neutral-300 flex items-center justify-between">
              <span>{hasSizes ? '3. Add-on Extras & Dips' : 'Add-on Extras & Dips'}</span>
              <span className="text-[10px] text-neutral-500 font-normal">Select multiple</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {ADDON_OPTIONS.map((addon) => {
                const isChecked = selectedAddons.includes(addon.id);
                return (
                  <button
                    key={addon.id}
                    type="button"
                    onClick={() => toggleAddon(addon.id)}
                    className={`p-2.5 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                      isChecked
                        ? 'border-amber-500 bg-amber-950/20 text-white'
                        : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:border-neutral-700'
                    }`}
                  >
                    <div>
                      <div className="font-semibold text-xs text-white">{addon.name}</div>
                      <div className="text-[11px] text-amber-400 font-mono tabular-nums">
                        +Rs. {addon.price}
                      </div>
                    </div>
                    <div
                      className={`w-4 h-4 rounded border flex items-center justify-center ${
                        isChecked
                          ? 'bg-amber-500 border-amber-500 text-neutral-950'
                          : 'border-neutral-700 bg-neutral-900'
                      }`}
                    >
                      {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 4. Special Instructions */}
          <div className="space-y-2">
            <label htmlFor={instructionsId} className="text-xs font-bold uppercase tracking-wider text-neutral-300 block">
              Special Instructions
            </label>
            <input
              id={instructionsId}
              type="text"
              placeholder="e.g. Mild spice, extra sauce, well-done bake..."
              value={specialInstructions}
              onChange={(e) => setSpecialInstructions(e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 outline-none"
            />
          </div>
        </div>

        {/* Footer: Quantity + Dynamic Total + Confirm Button */}
        <div className="p-4 sm:p-5 border-t border-neutral-800 bg-neutral-950 flex flex-wrap items-center justify-between gap-4">
          {/* Quantity Stepper */}
          <div className="flex items-center gap-2 bg-neutral-900 border border-neutral-800 rounded-xl p-1">
            <button
              type="button"
              onClick={() => setQuantity(Math.max(1, quantity - 1))}
              disabled={quantity <= 1}
              className="w-7 h-7 flex items-center justify-center text-neutral-400 hover:text-white rounded-lg disabled:opacity-40 cursor-pointer"
            >
              <Minus className="w-3.5 h-3.5" />
            </button>
            <span className="w-8 text-center font-bold text-sm text-white font-mono tabular-nums">
              {quantity}
            </span>
            <button
              type="button"
              onClick={() => setQuantity(quantity + 1)}
              className="w-7 h-7 flex items-center justify-center text-neutral-400 hover:text-white rounded-lg cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Add to Bag Action */}
          <button
            type="button"
            onClick={handleAdd}
            className="flex-1 sm:flex-initial px-6 py-3 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-2 active:scale-95 shadow-lg shadow-amber-500/20 cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            <span>Add to Bag · Rs. {totalPrice.toLocaleString()}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
