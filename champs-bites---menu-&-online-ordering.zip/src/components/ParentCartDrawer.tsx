import { useState, useId, useEffect } from 'react';
import { CustomizedCartItem } from './ParentCustomizeModal';
import { RESTAURANT_INFO } from '../data/parentSiteData';

interface ParentCartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CustomizedCartItem[];
  onUpdateQty: (index: number, delta: number) => void;
  onRemoveItem: (index: number) => void;
  onClearCart: () => void;
}

export function ParentCartDrawer({
  isOpen,
  onClose,
  cart,
  onUpdateQty,
  onRemoveItem,
  onClearCart,
}: ParentCartDrawerProps) {
  const nameId = useId();
  const phoneId = useId();
  const addressId = useId();

  const [customerName, setCustomerName] = useState(() => {
    try {
      return localStorage.getItem('cb_customer_name') || '';
    } catch {
      return '';
    }
  });
  const [customerPhone, setCustomerPhone] = useState(() => {
    try {
      return localStorage.getItem('cb_customer_phone') || '';
    } catch {
      return '';
    }
  });
  const [customerAddress, setCustomerAddress] = useState(() => {
    try {
      return localStorage.getItem('cb_customer_address') || '';
    } catch {
      return '';
    }
  });
  const [showAddressForm, setShowAddressForm] = useState(false);

  useEffect(() => {
    try {
      if (customerName) localStorage.setItem('cb_customer_name', customerName);
      if (customerPhone) localStorage.setItem('cb_customer_phone', customerPhone);
      if (customerAddress) localStorage.setItem('cb_customer_address', customerAddress);
    } catch {
      // ignore
    }
  }, [customerName, customerPhone, customerAddress]);

  if (!isOpen) return null;

  const totalCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const deliveryFee = 0; // FREE in Gujranwala
  const grandTotal = subtotal + deliveryFee;

  const handleWhatsAppCheckout = () => {
    if (cart.length === 0) return;

    let message = `*🍕 NEW ORDER - CHAMPS BITES GUJRANWALA 🍕*\n`;
    message += `==============================\n`;
    if (customerName.trim()) message += `*Customer:* ${customerName.trim()}\n`;
    if (customerPhone.trim()) message += `*Phone:* ${customerPhone.trim()}\n`;
    if (customerAddress.trim()) message += `*Delivery Address:* ${customerAddress.trim()}\n`;
    message += `*City:* Gujranwala\n`;
    message += `==============================\n\n`;
    message += `*SELECTED ITEMS & BASE PRICES:*\n`;

    cart.forEach((item, idx) => {
      const lineTotal = item.price * item.quantity;
      message += `${idx + 1}. *${item.name}*\n`;
      if (item.details) message += `   ▫ _${item.details}_\n`;
      message += `   ▫ Base Price: Rs. ${item.price.toLocaleString()} x ${item.quantity}\n`;
      message += `   ▫ Item Total: *Rs. ${lineTotal.toLocaleString()}*\n\n`;
    });

    message += `==============================\n`;
    message += `*Total Items:* ${totalCount}\n`;
    message += `*Delivery Charge:* FREE (Gujranwala)\n`;
    message += `*GRAND TOTAL:* *Rs. ${grandTotal.toLocaleString()}*\n`;
    message += `==============================\n`;
    message += `Please confirm my order and share estimated delivery time. Shukriya!`;

    const encodedMsg = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/${RESTAURANT_INFO.whatsappRaw}?text=${encodedMsg}`;
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex justify-end animate-in fade-in duration-200">
      <div className="absolute inset-0" onClick={onClose} />

      <div className="relative w-full max-w-lg bg-zinc-900 border-l border-zinc-800 flex flex-col shadow-2xl h-full z-10 animate-in slide-in-from-right duration-300">
        {/* Header with WhatsApp Branding */}
        <div className="p-4 sm:p-5 bg-zinc-950 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-emerald-500 text-white flex items-center justify-center shadow-lg shadow-emerald-950">
              <i className="fa-brands fa-whatsapp text-2xl"></i>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black text-white font-heading">
                  Order Summary List
                </h3>
                <span className="bg-red-600 text-white font-extrabold text-[11px] px-2 py-0.5 rounded-full">
                  {totalCount}
                </span>
              </div>
              <p className="text-[11px] text-zinc-400">
                Review items, base prices, and buy directly via WhatsApp
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-zinc-800 text-zinc-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
            title="Close Drawer"
          >
            <i className="fa-solid fa-xmark text-base"></i>
          </button>
        </div>

        {/* Selected Items List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center p-6 text-center">
              <div className="w-20 h-20 bg-zinc-800/80 rounded-2xl flex items-center justify-center text-zinc-500 text-3xl mb-4 border border-zinc-700/60">
                <i className="fa-solid fa-basket-shopping"></i>
              </div>
              <p className="text-white font-black text-lg mb-1.5 font-heading">Your Order Bag is Empty</p>
              <p className="text-xs text-zinc-400 max-w-xs mb-5 leading-relaxed">
                Scroll through the menu to select pizzas, burgers, desserts, cold drinks, or deals!
              </p>
              <button
                type="button"
                onClick={onClose}
                className="bg-gradient-to-r from-red-600 to-amber-500 hover:from-red-500 hover:to-amber-400 text-black font-extrabold text-xs px-6 py-3 rounded-full transition-all shadow-lg cursor-pointer"
              >
                Browse Delicious Menu
              </button>
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between pb-1">
                <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider">
                  Selected Items ({totalCount})
                </span>
                <button
                  type="button"
                  onClick={onClearCart}
                  className="text-[11px] text-red-400 hover:text-red-300 font-semibold cursor-pointer transition-colors"
                >
                  Clear All
                </button>
              </div>

              {cart.map((item, index) => {
                const lineTotal = item.price * item.quantity;
                return (
                  <div
                    key={item.id}
                    className="bg-zinc-950 p-3.5 sm:p-4 rounded-2xl border border-zinc-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md hover:border-zinc-700 transition-colors"
                  >
                    <div className="flex items-start gap-3 flex-1 min-w-0">
                      {item.image ? (
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-12 h-12 rounded-xl object-cover border border-zinc-800 flex-shrink-0"
                        />
                      ) : (
                        <div className="w-12 h-12 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-amber-400 text-lg flex-shrink-0">
                          <i className="fa-solid fa-utensils"></i>
                        </div>
                      )}
                      <div className="flex-1 min-w-0">
                        <h4 className="text-sm font-extrabold text-white truncate font-heading">
                          {item.name}
                        </h4>
                        {item.details && (
                          <p className="text-[11px] text-amber-400 font-semibold truncate mt-0.5">
                            {item.details}
                          </p>
                        )}
                        {/* Base Price clearly shown */}
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-[11px] text-zinc-400 font-medium">Base Price:</span>
                          <span className="text-xs font-black text-amber-400 font-mono">
                            Rs. {item.price.toLocaleString()}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Stepper + Item Total + Remove */}
                    <div className="flex items-center justify-between sm:justify-end gap-3 pt-2 sm:pt-0 border-t sm:border-t-0 border-zinc-900">
                      {/* Quantity Stepper */}
                      <div className="flex items-center bg-zinc-900 border border-zinc-700 rounded-xl overflow-hidden">
                        <button
                          type="button"
                          onClick={() => onUpdateQty(index, -1)}
                          className="w-7 h-7 text-zinc-400 hover:text-white hover:bg-zinc-800 flex items-center justify-center text-xs transition-colors cursor-pointer"
                          title="Decrease quantity"
                        >
                          <i className="fa-solid fa-minus"></i>
                        </button>
                        <span className="text-xs font-black text-white px-2.5 min-w-[24px] text-center">
                          {item.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => onUpdateQty(index, 1)}
                          className="w-7 h-7 text-zinc-400 hover:text-white hover:bg-zinc-800 flex items-center justify-center text-xs transition-colors cursor-pointer"
                          title="Increase quantity"
                        >
                          <i className="fa-solid fa-plus"></i>
                        </button>
                      </div>

                      {/* Line Item Total */}
                      <div className="text-right min-w-[70px]">
                        <span className="text-xs font-black text-white font-mono block">
                          Rs. {lineTotal.toLocaleString()}
                        </span>
                        <span className="text-[9px] text-zinc-500 uppercase">Subtotal</span>
                      </div>

                      {/* Delete */}
                      <button
                        type="button"
                        onClick={() => onRemoveItem(index)}
                        className="w-7 h-7 rounded-lg bg-zinc-900 hover:bg-red-950/60 text-zinc-500 hover:text-red-400 flex items-center justify-center text-xs transition-colors cursor-pointer"
                        title="Remove item"
                      >
                        <i className="fa-solid fa-trash-can"></i>
                      </button>
                    </div>
                  </div>
                );
              })}
            </>
          )}
        </div>

        {/* Checkout Footer Section */}
        {cart.length > 0 && (
          <div className="p-4 sm:p-5 bg-zinc-950 border-t border-zinc-800 space-y-3.5">
            {/* Bill Summary */}
            <div className="space-y-1.5 text-xs border-b border-zinc-800/80 pb-3">
              <div className="flex justify-between text-zinc-400">
                <span>Items Subtotal ({totalCount} items)</span>
                <span className="font-bold text-white">Rs. {subtotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span className="flex items-center gap-1.5">
                  <i className="fa-solid fa-motorcycle text-emerald-400 text-xs"></i>
                  <span>Delivery in Gujranwala City</span>
                </span>
                <span className="text-emerald-400 font-extrabold uppercase">FREE DELIVERY</span>
              </div>
              <div className="flex justify-between text-base font-black text-amber-400 pt-1.5">
                <span>Total Amount to Pay</span>
                <span className="text-xl font-heading">Rs. {grandTotal.toLocaleString()}</span>
              </div>
            </div>

            {/* Optional Delivery Address Accordion */}
            <div className="space-y-2">
              <button
                type="button"
                onClick={() => setShowAddressForm(!showAddressForm)}
                className="w-full flex items-center justify-between text-left text-xs font-bold text-zinc-300 hover:text-white bg-zinc-900 border border-zinc-800 px-3 py-2 rounded-xl transition-all cursor-pointer"
              >
                <span className="flex items-center gap-2">
                  <i className="fa-solid fa-location-dot text-red-500 text-xs"></i>
                  <span>{customerAddress ? 'Edit Delivery Info (Saved)' : 'Add Delivery Address (Optional)'}</span>
                </span>
                <i className={`fa-solid fa-chevron-${showAddressForm ? 'up' : 'down'} text-[10px] text-zinc-400`}></i>
              </button>

              {showAddressForm && (
                <div className="space-y-2 text-xs p-3 bg-zinc-900/90 border border-zinc-800 rounded-xl animate-in fade-in duration-150">
                  <div>
                    <label htmlFor={nameId} className="sr-only">Your Name</label>
                    <input
                      id={nameId}
                      type="text"
                      placeholder="Your Name (Optional)"
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-amber-400 text-xs"
                    />
                  </div>
                  <div>
                    <label htmlFor={phoneId} className="sr-only">Contact Number</label>
                    <input
                      id={phoneId}
                      type="tel"
                      placeholder="Mobile Number (Optional)"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-amber-400 text-xs"
                    />
                  </div>
                  <div>
                    <label htmlFor={addressId} className="sr-only">Delivery Address</label>
                    <textarea
                      id={addressId}
                      rows={2}
                      placeholder="Address in Gujranwala (Optional)"
                      value={customerAddress}
                      onChange={(e) => setCustomerAddress(e.target.value)}
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-amber-400 text-xs resize-none"
                    ></textarea>
                  </div>
                </div>
              )}
            </div>

            {/* Primary Buy Now WhatsApp Button */}
            <button
              type="button"
              onClick={handleWhatsAppCheckout}
              className="w-full bg-gradient-to-r from-emerald-600 via-emerald-500 to-emerald-600 hover:from-emerald-500 hover:to-emerald-400 text-white font-black py-3.5 px-4 rounded-2xl shadow-xl shadow-emerald-950/60 flex items-center justify-center gap-2.5 text-sm sm:text-base transition-all active:scale-98 cursor-pointer ring-2 ring-emerald-500/30"
            >
              <i className="fa-brands fa-whatsapp text-2xl"></i>
              <span>BUY NOW ON WHATSAPP &middot; Rs. {grandTotal.toLocaleString()}</span>
            </button>

            {/* Continue Browsing Button */}
            <button
              type="button"
              onClick={onClose}
              className="w-full text-center text-xs font-bold text-zinc-400 hover:text-zinc-200 py-1 cursor-pointer transition-colors"
            >
              + Keep Browsing Menu (Add Burgers, Drinks, Pizzas, Desserts)
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

