import React from 'react';
import { CustomizedCartItem } from './ParentCustomizeModal';
import { RESTAURANT_INFO } from '../data/parentSiteData';

interface WhatsAppFloatingCartProps {
  cart: CustomizedCartItem[];
  onOpenCart: () => void;
  onQuickWhatsAppOrder: () => void;
}

export const WhatsAppFloatingCart: React.FC<WhatsAppFloatingCartProps> = ({
  cart,
  onOpenCart,
  onQuickWhatsAppOrder,
}) => {
  const totalCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const totalPrice = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <>
      {/* Floating WhatsApp Cart Widget - Fixed Bottom Right */}
      <div className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-40 flex flex-col items-end gap-2 pointer-events-none">
        {/* If cart has items: Floating Interactive Notification Bar */}
        {totalCount > 0 ? (
          <div className="pointer-events-auto bg-zinc-950/95 backdrop-blur-md border border-emerald-500/50 shadow-2xl shadow-emerald-950/60 rounded-2xl p-2.5 sm:p-3 flex items-center gap-3 animate-in slide-in-from-bottom-5 duration-300 max-w-[92vw] sm:max-w-md ring-2 ring-emerald-500/20">
            {/* WhatsApp Icon with WhatsApp-style Notification Badge */}
            <button
              type="button"
              onClick={onOpenCart}
              className="relative w-12 h-12 rounded-xl bg-gradient-to-tr from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white flex items-center justify-center shadow-lg shadow-emerald-900/40 active:scale-95 transition-all cursor-pointer flex-shrink-0 group"
              title="Click to view full order list"
            >
              <i className="fa-brands fa-whatsapp text-2xl group-hover:scale-110 transition-transform"></i>
              {/* WhatsApp Unread-style Notification Badge */}
              <span className="absolute -top-2 -right-2 bg-red-600 border-2 border-zinc-950 text-white font-black text-xs min-w-[22px] h-[22px] px-1 rounded-full flex items-center justify-center shadow-md animate-pulse">
                {totalCount}
              </span>
            </button>

            {/* Price & Items Summary */}
            <div
              onClick={onOpenCart}
              className="cursor-pointer text-left select-none pr-1"
            >
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] sm:text-xs text-zinc-400 uppercase font-bold tracking-wider">
                  Total Order:
                </span>
                <span className="text-base sm:text-lg font-black text-amber-400 font-heading">
                  Rs. {totalPrice.toLocaleString()}
                </span>
              </div>
              <p className="text-[11px] text-emerald-400 font-medium flex items-center gap-1 truncate">
                <i className="fa-solid fa-cart-shopping text-[10px]"></i>
                <span>{totalCount} {totalCount === 1 ? 'item' : 'items'} in bag &middot; Click to view list</span>
              </p>
            </div>

            {/* Quick Actions */}
            <div className="flex items-center gap-1.5 flex-shrink-0">
              <button
                type="button"
                onClick={onOpenCart}
                className="bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-bold px-3 py-2 rounded-xl transition-all border border-zinc-700 active:scale-95 cursor-pointer hidden sm:flex items-center gap-1"
              >
                <span>View List</span>
                <i className="fa-solid fa-list-ul text-[10px]"></i>
              </button>

              <button
                type="button"
                onClick={onQuickWhatsAppOrder}
                className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black px-3.5 py-2 sm:py-2.5 rounded-xl transition-all shadow-md shadow-emerald-950 flex items-center gap-1.5 active:scale-95 cursor-pointer whitespace-nowrap"
              >
                <span>BUY NOW</span>
                <i className="fa-brands fa-whatsapp text-sm"></i>
              </button>
            </div>
          </div>
        ) : (
          /* Empty Cart: Subtle Floating WhatsApp Support / Order Button */
          <div className="pointer-events-auto">
            <a
              href={`https://wa.me/${RESTAURANT_INFO.whatsappRaw}?text=${encodeURIComponent('Hi Champs Bites Gujranwala! I want to check the menu and order.')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-gradient-to-tr from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white px-4 py-2.5 rounded-full shadow-xl shadow-emerald-950/50 flex items-center gap-2 text-xs font-extrabold transition-all transform hover:-translate-y-0.5 active:scale-95 border border-emerald-400/30 group"
            >
              <i className="fa-brands fa-whatsapp text-xl group-hover:scale-110 transition-transform"></i>
              <span>WhatsApp Order</span>
            </a>
          </div>
        )}
      </div>
    </>
  );
};
