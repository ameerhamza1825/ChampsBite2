import { ArrowRight, Sparkles, Flame } from 'lucide-react';
import { MenuItem, PizzaSize } from '../types';
import { MENU_ITEMS } from '../data/menuData';
import { MenuCard } from './MenuCard';

interface FeaturedSectionProps {
  onAddToCart: (item: MenuItem, size?: PizzaSize) => void;
  onCustomize: (item: MenuItem) => void;
  onViewFullMenu: () => void;
}

export function FeaturedSection({ onAddToCart, onCustomize, onViewFullMenu }: FeaturedSectionProps) {
  // Curate 6 top best-sellers for instant landing page load
  const featuredIds = [3, 1, 45, 16, 42, 49]; // Champs Special, Malai Boti, Zinger Burger, Club Sandwich, Platter, Brownie
  const featuredItems = featuredIds
    .map((id) => MENU_ITEMS.find((item) => item.id === id))
    .filter(Boolean) as MenuItem[];

  return (
    <section className="py-16 bg-neutral-950 border-b border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs uppercase font-bold tracking-widest text-amber-500 mb-2">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>Customer Favorites</span>
            </div>
            <h2 className="text-3xl font-extrabold font-display text-white tracking-tight">
              Best Sellers &amp; Chef Specials
            </h2>
            <p className="text-neutral-400 text-xs sm:text-sm mt-1">
              Hand-picked crowd favorites baked and fried fresh to order.
            </p>
          </div>

          <button
            type="button"
            onClick={onViewFullMenu}
            className="self-start md:self-auto inline-flex items-center gap-2 px-4 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-amber-400 hover:text-amber-300 border border-neutral-800 hover:border-amber-500/40 rounded-xl text-xs font-bold transition-all cursor-pointer"
          >
            <span>Explore Full Menu ({MENU_ITEMS.length} items)</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* 6 Grid items */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredItems.map((item) => (
            <MenuCard
              key={item.id}
              item={item}
              onAddToCart={onAddToCart}
              onCustomize={onCustomize}
            />
          ))}
        </div>

        {/* Big Banner linking to Full Menu */}
        <div className="mt-12 text-center p-8 rounded-2xl bg-gradient-to-r from-amber-950/20 via-neutral-900 to-amber-950/20 border border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="text-left space-y-1">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Flame className="w-4 h-4 text-amber-500" />
              <span>Looking for our complete selection?</span>
            </h3>
            <p className="text-xs text-neutral-400">
              Browse all 15 pizza varieties, loaded cheesy fries, wings, pasta, desserts, and drinks with instant search.
            </p>
          </div>
          <button
            type="button"
            onClick={onViewFullMenu}
            className="px-6 py-3 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-lg shadow-amber-500/20 whitespace-nowrap cursor-pointer active:scale-95 flex items-center gap-2"
          >
            <span>Open Full Menu</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
}
