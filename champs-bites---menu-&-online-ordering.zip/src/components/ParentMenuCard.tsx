import { useState } from 'react';
import { MenuItemData } from '../data/parentSiteData';

export type PizzaSizeKey = 'small' | 'medium' | 'large' | 'xl';

export const PIZZA_SIZE_LABELS: Record<PizzaSizeKey, string> = {
  small: 'Small (6")',
  medium: 'Medium (9")',
  large: 'Large (12")',
  xl: 'X-Large (15")',
};

interface ParentMenuCardProps {
  item: MenuItemData;
  onAddToCart: (item: MenuItemData, size?: PizzaSizeKey, crownVariantIdx?: number) => void;
  onOpenCustomizer: (item: MenuItemData, preselectedSize?: PizzaSizeKey) => void;
}

export function ParentMenuCard({ item, onAddToCart, onOpenCustomizer }: ParentMenuCardProps) {
  const [selectedSize, setSelectedSize] = useState<PizzaSizeKey>('medium');
  const [selectedCrownIdx, setSelectedCrownIdx] = useState<number>(0);
  const [imgLoaded, setImgLoaded] = useState(false);
  const [addedAnim, setAddedAnim] = useState(false);

  // Price Calculation
  let calculatedPrice = 0;
  if (item.isPizza && item.prices) {
    calculatedPrice = item.prices[selectedSize];
  } else if (item.isCrown && item.variants) {
    calculatedPrice = item.variants[selectedCrownIdx].price;
  } else {
    calculatedPrice = item.price || 0;
  }

  const handleAddClick = () => {
    if (item.isPizza) {
      onAddToCart(item, selectedSize);
    } else if (item.isCrown) {
      onAddToCart(item, undefined, selectedCrownIdx);
    } else {
      onAddToCart(item);
    }
    setAddedAnim(true);
    setTimeout(() => setAddedAnim(false), 800);
  };

  return (
    <div className="glass-card glass-card-hover rounded-2xl overflow-hidden flex flex-col justify-between group border border-white/10 hover:border-amber-400/40 transition-all duration-300">
      <div>
        {/* Visual Image Header */}
        <div className="relative h-44 overflow-hidden bg-zinc-950">
          {!imgLoaded && (
            <div className="absolute inset-0 bg-zinc-900 animate-pulse flex items-center justify-center text-zinc-700 text-xs font-mono">
              Champs Bites
            </div>
          )}
          <img
            src={item.image}
            alt={item.name}
            loading="lazy"
            decoding="async"
            onLoad={() => setImgLoaded(true)}
            className={`w-full h-full object-cover group-hover:scale-105 transition-all duration-500 ${
              imgLoaded ? 'opacity-100' : 'opacity-0'
            }`}
            onError={(e) => {
              (e.target as HTMLElement).style.display = 'none';
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-transparent to-transparent pointer-events-none"></div>

          {/* Badges */}
          <div className="absolute top-3 left-3 flex flex-wrap gap-1.5 pointer-events-none">
            {item.badge && (
              <span className="bg-amber-400 text-zinc-950 text-[10px] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider shadow-md">
                {item.badge}
              </span>
            )}
            {item.isPizza && (
              <span className="bg-red-600/90 backdrop-blur-md text-white text-[10px] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider">
                Artisanal Pizza
              </span>
            )}
            {item.isCrown && (
              <span className="bg-amber-500/90 backdrop-blur-md text-zinc-950 text-[10px] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider">
                Crown Stuffed
              </span>
            )}
          </div>

          {/* Spicy / Veg icons */}
          <div className="absolute top-3 right-3 flex items-center gap-1.5 pointer-events-none">
            {item.isSpicy && (
              <span className="w-6 h-6 rounded-full bg-zinc-950/80 border border-red-500/50 flex items-center justify-center text-red-500 text-xs shadow" title="Spicy">
                <i className="fa-solid fa-fire"></i>
              </span>
            )}
            {item.isVegetarian && (
              <span className="w-6 h-6 rounded-full bg-zinc-950/80 border border-emerald-500/50 flex items-center justify-center text-emerald-400 text-xs shadow" title="Vegetarian">
                <i className="fa-solid fa-leaf"></i>
              </span>
            )}
          </div>
        </div>

        {/* Card Body */}
        <div className="p-4 space-y-2">
          <h3 className="text-base font-extrabold text-white font-heading group-hover:text-amber-400 transition-colors">
            {item.name}
          </h3>
          <p className="text-xs text-zinc-400 line-clamp-2 leading-relaxed">
            {item.description}
          </p>
        </div>
      </div>

      {/* Interactive Size Calculation Feature & Actions Footer */}
      <div className="p-4 pt-0 space-y-3">
        {/* S M L XL Size Calculation Selector for Standard Pizzas */}
        {item.isPizza && item.prices && (
          <div className="pt-2 border-t border-zinc-800/80 space-y-1.5">
            <div className="text-[10px] font-extrabold uppercase tracking-widest text-zinc-400">
              SELECT SIZE
            </div>

            {/* Segmented S M L XL Buttons */}
            <div className="grid grid-cols-4 gap-1 p-1 bg-zinc-950/90 rounded-xl border border-zinc-800">
              {(['small', 'medium', 'large', 'xl'] as PizzaSizeKey[]).map((szKey) => {
                const isSelected = selectedSize === szKey;
                const letter = szKey === 'small' ? 'S' : szKey === 'medium' ? 'M' : szKey === 'large' ? 'L' : 'XL';
                return (
                  <button
                    key={szKey}
                    type="button"
                    onClick={() => setSelectedSize(szKey)}
                    className={`py-1.5 rounded-lg text-xs font-black transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-amber-400 text-zinc-950 shadow-md font-extrabold'
                        : 'text-zinc-400 hover:text-white hover:bg-zinc-800/60'
                    }`}
                    title={`${PIZZA_SIZE_LABELS[szKey]} — Rs. ${item.prices![szKey]}`}
                  >
                    {letter}
                  </button>
                );
              })}
            </div>

            {/* Live Size Label & Dimension Display */}
            <div className="flex items-center justify-between text-[11px] text-zinc-400 px-0.5">
              <span className="font-semibold text-zinc-300">{PIZZA_SIZE_LABELS[selectedSize]}</span>
              <span className="font-mono font-bold text-amber-400">Rs. {item.prices![selectedSize]}</span>
            </div>
          </div>
        )}

        {/* Crown Crust Size Selector */}
        {item.isCrown && item.variants && (
          <div className="pt-2 border-t border-zinc-800/80 space-y-1.5">
            <div className="text-[10px] font-extrabold uppercase tracking-widest text-amber-400">
              SELECT CROWN SIZE
            </div>
            <div className="grid grid-cols-3 gap-1 p-1 bg-zinc-950/90 rounded-xl border border-zinc-800">
              {item.variants.map((v, idx) => {
                const isSelected = selectedCrownIdx === idx;
                const label = idx === 0 ? 'M (9")' : idx === 1 ? 'L (12")' : 'XL (15")';
                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setSelectedCrownIdx(idx)}
                    className={`py-1.5 rounded-lg text-[11px] font-extrabold transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-amber-400 text-zinc-950 shadow-md'
                        : 'text-zinc-400 hover:text-white hover:bg-zinc-800/60'
                    }`}
                  >
                    {label}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Price & Action Row */}
        <div className="flex items-center justify-between border-t border-zinc-800/80 pt-3 gap-2">
          <div>
            <div className="text-[10px] text-zinc-400 uppercase font-semibold">Price</div>
            <div className="text-lg font-black text-amber-400 font-heading">
              Rs. {calculatedPrice.toLocaleString()}
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Customize Sliders Button for Pizzas */}
            {item.isPizza && (
              <button
                type="button"
                onClick={() => onOpenCustomizer(item, selectedSize)}
                className="w-9 h-9 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white flex items-center justify-center transition-all cursor-pointer"
                title="Customize Crust & Toppings"
              >
                <i className="fa-solid fa-sliders text-xs"></i>
              </button>
            )}

            {/* Quick Add Button */}
            <button
              type="button"
              onClick={handleAddClick}
              className={`px-4 py-2.5 rounded-xl font-extrabold text-xs flex items-center gap-1.5 transition-all shadow-md active:scale-95 cursor-pointer ${
                addedAnim
                  ? 'bg-emerald-500 text-white'
                  : 'bg-gradient-to-r from-red-600 to-amber-500 hover:from-red-500 hover:to-amber-400 text-zinc-950'
              }`}
            >
              {addedAnim ? (
                <>
                  <i className="fa-solid fa-check"></i>
                  <span>Added!</span>
                </>
              ) : (
                <>
                  <i className="fa-solid fa-plus text-[10px]"></i>
                  <span>Add</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
