import { Crown, Sparkles, MessageCircle, ArrowRight } from 'lucide-react';
import { ASSETS, RESTAURANT_INFO } from '../data/menuData';

interface CrownCrustBannerProps {
  onCustomizeCrownPizza: () => void;
}

export function CrownCrustBanner({ onCustomizeCrownPizza }: CrownCrustBannerProps) {
  const sizes = [
    { size: '9" Regular', price: 1150 },
    { size: '12" Large', price: 1550 },
    { size: '16" X-Large', price: 2450 },
    { size: 'Stuffed Add-on', price: 200, isAddon: true },
  ];

  return (
    <section id="crown-crust" className="py-14 bg-neutral-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="relative rounded-2xl overflow-hidden border border-amber-500/30 bg-gradient-to-br from-amber-950/30 via-neutral-900 to-neutral-950 p-6 sm:p-10 lg:p-12">
          {/* Subtle background glow */}
          <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative">
            {/* Left Content */}
            <div className="lg:col-span-7 space-y-5">
              <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400">
                <Crown className="w-4 h-4 text-amber-400" />
                <span>Signature Stuffed Perfection</span>
              </div>

              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold font-display text-white tracking-tight text-balance">
                Crown Crust &amp; <span className="text-amber-500">Stuffed Crust</span> Specialties
              </h2>

              <p className="text-neutral-300 text-sm sm:text-base leading-relaxed max-w-xl">
                Elevate your pizza experience with our artisanal stuffed crusts. Choose between molten creamy <strong className="text-amber-400">Mozzarella Cheese Stuffed</strong> or savory seasoned <strong className="text-amber-400">Chicken Kabab Stuffed</strong> pockets along the golden outer rim.
              </p>

              {/* Price Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                {sizes.map((s, idx) => (
                  <div
                    key={idx}
                    className="bg-neutral-950/60 border border-neutral-800 p-3 rounded-xl text-center backdrop-blur-sm"
                  >
                    <div className="text-[11px] text-neutral-400 mb-1">{s.size}</div>
                    <div className="text-base font-extrabold text-amber-400 font-mono tabular-nums">
                      {s.isAddon ? `+Rs. ${s.price}` : `Rs. ${s.price.toLocaleString()}`}
                    </div>
                  </div>
                ))}
              </div>

              {/* CTA buttons */}
              <div className="flex flex-wrap items-center gap-3 pt-3">
                <button
                  type="button"
                  onClick={onCustomizeCrownPizza}
                  className="px-5 py-3 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs uppercase tracking-wider rounded-xl transition-all flex items-center gap-2 shadow-lg shadow-amber-500/20 active:scale-95 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Customize Crown Pizza</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <a
                  href={`https://wa.me/${RESTAURANT_INFO.whatsappRaw}?text=${encodeURIComponent(
                    'Hi Champs Bites! I would like to order a Crown Crust / Stuffed Crust pizza.'
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-5 py-3 bg-neutral-900 hover:bg-neutral-800 text-neutral-200 hover:text-white font-semibold text-xs border border-neutral-700/80 rounded-xl transition-all flex items-center gap-2 cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4 text-emerald-400" />
                  <span>Order on WhatsApp</span>
                </a>
              </div>
            </div>

            {/* Right Visual Image */}
            <div className="lg:col-span-5 flex justify-center">
              <div className="relative w-full max-w-sm aspect-[4/3] rounded-xl overflow-hidden border border-neutral-800 shadow-xl group">
                <img
                  src={ASSETS.crownCrust}
                  alt="Champs Bites Crown Crust Pizza"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  onError={(e) => {
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/70 via-transparent to-transparent pointer-events-none" />
                <div className="absolute bottom-3 left-3 right-3 text-center bg-neutral-950/80 backdrop-blur-md py-1.5 px-3 rounded-lg border border-neutral-700/50">
                  <span className="text-xs font-bold text-amber-400">Available on all pizza flavors</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
