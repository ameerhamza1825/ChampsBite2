import { ShoppingBag, MessageCircle, Utensils, Flame, Info } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/menuData';

export type AppView = 'home' | 'menu' | 'deals' | 'about';

interface HeaderProps {
  currentView: AppView;
  onNavigate: (view: AppView) => void;
  totalCartCount: number;
  totalCartAmount: number;
  onOpenCart: () => void;
}

export function Header({
  currentView,
  onNavigate,
  totalCartCount,
  totalCartAmount,
  onOpenCart,
}: HeaderProps) {
  return (
    <header className="sticky top-0 z-40 bg-neutral-950/95 backdrop-blur-md border-b border-neutral-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-18 flex items-center justify-between gap-4">
        {/* Zone 1: Single text element wordmark */}
        <button
          type="button"
          onClick={() => onNavigate('home')}
          className="text-2xl font-extrabold tracking-tight font-display text-white hover:text-amber-400 transition-colors shrink-0 text-left cursor-pointer"
        >
          CHAMPS <span className="text-amber-500">BITES</span>
        </button>

        {/* Zone 2: Page Navigation tabs */}
        <nav className="hidden md:flex items-center gap-1 bg-neutral-900 border border-neutral-800 p-1 rounded-xl text-xs font-semibold">
          <button
            type="button"
            onClick={() => onNavigate('home')}
            className={`px-3.5 py-1.5 rounded-lg transition-colors cursor-pointer ${
              currentView === 'home'
                ? 'bg-amber-500 text-neutral-950 font-bold shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Home
          </button>
          <button
            type="button"
            onClick={() => onNavigate('menu')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg transition-colors cursor-pointer ${
              currentView === 'menu'
                ? 'bg-amber-500 text-neutral-950 font-bold shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Utensils className="w-3.5 h-3.5" />
            <span>Full Menu</span>
          </button>
          <button
            type="button"
            onClick={() => onNavigate('deals')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg transition-colors cursor-pointer ${
              currentView === 'deals'
                ? 'bg-amber-500 text-neutral-950 font-bold shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Flame className="w-3.5 h-3.5 text-amber-500" />
            <span>Special Deals</span>
          </button>
          <button
            type="button"
            onClick={() => onNavigate('about')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg transition-colors cursor-pointer ${
              currentView === 'about'
                ? 'bg-amber-500 text-neutral-950 font-bold shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Info className="w-3.5 h-3.5" />
            <span>About &amp; Contact</span>
          </button>
        </nav>

        {/* Zone 3: Actions */}
        <div className="flex items-center gap-2.5">
          <a
            href={`https://wa.me/${RESTAURANT_INFO.whatsappRaw}?text=${encodeURIComponent('Hi Champs Bites! I would like to place an order.')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-emerald-400 bg-emerald-950/40 border border-emerald-800/40 rounded-lg hover:bg-emerald-900/50 transition-colors whitespace-nowrap"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>WhatsApp</span>
          </a>

          <button
            onClick={onOpenCart}
            aria-label="View shopping bag"
            className="relative flex items-center gap-2 px-3.5 py-2 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs uppercase tracking-wider rounded-lg transition-all active:scale-95 shadow-md shadow-amber-500/20 whitespace-nowrap cursor-pointer"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Bag</span>
            {totalCartCount > 0 ? (
              <span className="flex items-center gap-1 bg-neutral-950 text-amber-400 px-1.5 py-0.5 rounded text-[11px] font-mono tabular-nums font-bold">
                {totalCartCount} · Rs. {totalCartAmount.toLocaleString()}
              </span>
            ) : (
              <span className="bg-neutral-950/20 px-1.5 py-0.5 rounded text-[10px] font-bold">0</span>
            )}
          </button>
        </div>
      </div>

      {/* Mobile Sub-Navigation Bar */}
      <div className="md:hidden flex items-center justify-around border-t border-neutral-850 px-2 py-1.5 bg-neutral-900/80 text-[11px] font-semibold">
        <button
          type="button"
          onClick={() => onNavigate('home')}
          className={`py-1 px-2.5 rounded-lg transition-colors cursor-pointer ${
            currentView === 'home' ? 'text-amber-400 bg-neutral-800 font-bold' : 'text-neutral-400'
          }`}
        >
          Home
        </button>
        <button
          type="button"
          onClick={() => onNavigate('menu')}
          className={`py-1 px-2.5 rounded-lg transition-colors cursor-pointer ${
            currentView === 'menu' ? 'text-amber-400 bg-neutral-800 font-bold' : 'text-neutral-400'
          }`}
        >
          Full Menu
        </button>
        <button
          type="button"
          onClick={() => onNavigate('deals')}
          className={`py-1 px-2.5 rounded-lg transition-colors cursor-pointer ${
            currentView === 'deals' ? 'text-amber-400 bg-neutral-800 font-bold' : 'text-neutral-400'
          }`}
        >
          Deals
        </button>
        <button
          type="button"
          onClick={() => onNavigate('about')}
          className={`py-1 px-2.5 rounded-lg transition-colors cursor-pointer ${
            currentView === 'about' ? 'text-amber-400 bg-neutral-800 font-bold' : 'text-neutral-400'
          }`}
        >
          About
        </button>
      </div>
    </header>
  );
}
