import { useState, useEffect } from 'react';
import { Phone, MessageCircle, Clock, Bike } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/menuData';

export function TopBar() {
  const [isOpen, setIsOpen] = useState(true);

  useEffect(() => {
    const checkOpen = () => {
      const currentHour = new Date().getHours();
      // Open 12:00 PM (12) to 2:00 AM (2)
      const open = currentHour >= 12 || currentHour < 2;
      setIsOpen(open);
    };
    checkOpen();
    const interval = setInterval(checkOpen, 60000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-neutral-900/90 border-b border-neutral-800 text-xs text-neutral-300 py-2">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-wrap items-center justify-between gap-3">
        {/* Left: Delivery & Open status */}
        <div className="flex items-center gap-4 flex-wrap">
          <div className="flex items-center gap-1.5 font-medium text-amber-400">
            <Bike className="w-3.5 h-3.5" />
            <span>Home Delivery Across City</span>
          </div>

          <div className="flex items-center gap-2 text-neutral-400">
            <span className="relative flex h-2 w-2">
              {isOpen ? (
                <>
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </>
              ) : (
                <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
              )}
            </span>
            <span className={isOpen ? 'text-emerald-400 font-semibold' : 'text-rose-400 font-semibold'}>
              {isOpen ? 'Open Now' : 'Closed Now'}
            </span>
            <span className="text-neutral-500 hidden sm:inline">·</span>
            <span className="hidden sm:inline flex items-center gap-1 text-neutral-400">
              <Clock className="w-3 h-3 text-neutral-500" />
              {RESTAURANT_INFO.openingHours}
            </span>
          </div>
        </div>

        {/* Right: Phone & WhatsApp */}
        <div className="flex items-center gap-4">
          <a
            href={`tel:${RESTAURANT_INFO.phone}`}
            className="flex items-center gap-1.5 text-neutral-300 hover:text-amber-400 transition-colors font-medium"
          >
            <Phone className="w-3.5 h-3.5 text-amber-500" />
            <span>{RESTAURANT_INFO.phone}</span>
          </a>

          <a
            href={`https://wa.me/${RESTAURANT_INFO.whatsappRaw}?text=${encodeURIComponent('Hi Champs Bites! I would like to check the menu and place an order.')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 bg-emerald-600/20 text-emerald-400 hover:bg-emerald-600 hover:text-white border border-emerald-500/30 px-2.5 py-0.5 rounded-full transition-all text-xs font-semibold"
          >
            <MessageCircle className="w-3 h-3" />
            <span>WhatsApp</span>
          </a>
        </div>
      </div>
    </div>
  );
}
