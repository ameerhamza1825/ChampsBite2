export const ASSETS = {
  heroPizza: '/src/assets/images/hero_pizza_showcase_1790500778099.jpg',
  crownCrust: '/src/assets/images/crown_crust_showcase_1790500815268.jpg',
  burgerShowcase: '/src/assets/images/deal_burger_showcase_1790500790006.jpg',
  starterShowcase: '/src/assets/images/starter_platter_showcase_1790500802477.jpg',
  clubSandwich: '/src/assets/images/club_sandwich_1790501971947.jpg',
  shawarmaRoll: '/src/assets/images/zinger_shaw_roll_1790512716981.jpg',
  crispyZingerWrap: '/src/assets/images/crispy_zinger_wrap_1790512686983.jpg',
  openShawarmaPlatter: '/src/assets/images/open_shawarma_plat_1790512700270.jpg',
  zingerShawarmaRoll: '/src/assets/images/zinger_shaw_roll_1790512716981.jpg',
  creamyPasta: '/src/assets/images/creamy_pasta_1790501998254.jpg',
  fudgeBrownie: '/src/assets/images/fudge_brownie_1790502010503.jpg',
  coldDrinks: '/src/assets/images/cold_drinks_1790502024451.jpg',
  mineralWater: '/src/assets/images/chilled_mineral_water_1790506497974.jpg',
  crispyFries: '/src/assets/images/crispy_fries_1790502040965.jpg',
  iceCream: '/src/assets/images/ice_cream_scoops_1790501955912.jpg',
  loadedFries: '/src/assets/images/loaded_cheese_fries_1790505559465.jpg',
  bakedWings: '/src/assets/images/baked_chicken_wings_1790505585774.jpg',
  mozzarellaSticks: '/src/assets/images/mozzarella_sticks_1790505599420.jpg',
};

export const RESTAURANT_INFO = {
  name: 'Champs Bites',
  tagline: 'Artisanal Pizzeria · Magic In First Bite',
  city: 'Gujranwala',
  address: 'Sheikhupura Road, Khyali Paper Mill, Near Bashir Sons Pharmacy, Gujranwala',
  phone: '0302-6640106',
  landline: '055-8178072',
  whatsappRaw: '923026640106',
  hours: '12:00 PM – 2:00 AM daily',
  deliveryHours: '12:00 PM – 1:30 AM',
  deliveryFee: 0, // Free Delivery across Gujranwala
};

export interface PizzaPriceMap {
  small: number;
  medium: number;
  large: number;
  xl: number;
}

export interface CrownVariant {
  size: string;
  price: number;
}

export type MenuCategoryType =
  | 'all'
  | 'ultimate'
  | 'legend'
  | 'crown'
  | 'burgers'
  | 'sandwich_pasta'
  | 'wrap_shawarma'
  | 'fries_starters'
  | 'drinks'
  | 'water'
  | 'desserts';

export interface MenuItemData {
  id: string;
  name: string;
  category: MenuCategoryType;
  description: string;
  image: string;
  isPizza?: boolean;
  prices?: PizzaPriceMap;
  isCrown?: boolean;
  variants?: CrownVariant[];
  price?: number;
  badge?: string;
  isSpicy?: boolean;
  isVegetarian?: boolean;
}

export interface CategoryItem {
  id: MenuCategoryType;
  name: string;
  icon: string;
  shortLabel?: string;
}

export interface CategoryLineGroup {
  lineId: string;
  lineTitle: string;
  icon: string;
  badgeColor: string;
  items: CategoryItem[];
}

export const MENU_CATEGORY_LINES: CategoryLineGroup[] = [
  {
    lineId: 'line-pizza',
    lineTitle: 'Pizza Types',
    icon: 'fa-pizza-slice',
    badgeColor: 'text-amber-400 bg-amber-400/10 border-amber-400/30',
    items: [
      { id: 'ultimate', name: 'Ultimate Pizzas', icon: 'fa-pizza-slice' },
      { id: 'legend', name: 'Legend Pizzas', icon: 'fa-crown' },
      { id: 'crown', name: 'Crown Stuffed Crust', icon: 'fa-star' },
    ],
  },
  {
    lineId: 'line-burgers',
    lineTitle: 'Burgers & Wraps',
    icon: 'fa-burger',
    badgeColor: 'text-red-400 bg-red-400/10 border-red-400/30',
    items: [
      { id: 'burgers', name: 'Artisan Burgers', icon: 'fa-burger' },
      { id: 'wrap_shawarma', name: 'Wraps & Shawarma', icon: 'fa-scroll' },
      { id: 'sandwich_pasta', name: 'Sandwiches & Pastas', icon: 'fa-bowl-food' },
    ],
  },
  {
    lineId: 'line-sides-drinks',
    lineTitle: 'Fries, Drinks & Water',
    icon: 'fa-bottle-water',
    badgeColor: 'text-emerald-400 bg-emerald-400/10 border-emerald-400/30',
    items: [
      { id: 'fries_starters', name: 'Fries & Starters', icon: 'fa-fire' },
      { id: 'drinks', name: 'Cold Drinks', icon: 'fa-glass-water' },
      { id: 'water', name: 'Mineral Water 💧', icon: 'fa-droplet' },
      { id: 'desserts', name: 'Desserts & Sweets', icon: 'fa-ice-cream' },
    ],
  },
];

export const MENU_CATEGORIES: CategoryItem[] = [
  { id: 'all', name: 'All Menu Items', icon: 'fa-border-all' },
  ...MENU_CATEGORY_LINES.flatMap((line) => line.items),
];

export const ULTIMATE_PRICES: PizzaPriceMap = {
  small: 550,
  medium: 850,
  large: 1300,
  xl: 2250,
};

export const LEGEND_PRICES: PizzaPriceMap = {
  small: 500,
  medium: 800,
  large: 1200,
  xl: 2050,
};

export const PARENT_MENU_ITEMS: MenuItemData[] = [
  // --- ULTIMATE PIZZAS ---
  {
    id: 'ult-1',
    name: 'Malai Boti Pizza',
    category: 'ultimate',
    description: 'Creamy grilled malai boti chicken, mozzarella cheese, onions, capsicum & secret garlic mayo drizzle.',
    image: ASSETS.heroPizza,
    isPizza: true,
    prices: ULTIMATE_PRICES,
    badge: 'Best Seller',
  },
  {
    id: 'ult-2',
    name: 'Afghani Feast Pizza',
    category: 'ultimate',
    description: 'Authentic Afghani mild spiced chicken, loaded cheese, fresh green peppers & rich cream topping.',
    image: ASSETS.crownCrust,
    isPizza: true,
    prices: ULTIMATE_PRICES,
  },
  {
    id: 'ult-3',
    name: 'Champs Supreme Special',
    category: 'ultimate',
    description: 'Chef signature combination of 3 chicken flavors, black olives, sliced mushrooms, jalapenos & house sauce.',
    image: ASSETS.heroPizza,
    isPizza: true,
    prices: ULTIMATE_PRICES,
    badge: "Chef's Special",
  },
  {
    id: 'ult-4',
    name: 'Peri Peri Flame Pizza',
    category: 'ultimate',
    description: 'Fiery Peri Peri glazed chicken boti, red onions, mozzarella cheese & spicy drizzle.',
    image: ASSETS.crownCrust,
    isPizza: true,
    prices: ULTIMATE_PRICES,
    isSpicy: true,
  },
  {
    id: 'ult-5',
    name: 'Behari Kabab Pizza',
    category: 'ultimate',
    description: 'Authentic spiced Behari chicken kabab chunks with pickled onions and fresh mozzarella.',
    image: ASSETS.heroPizza,
    isPizza: true,
    prices: ULTIMATE_PRICES,
  },

  // --- LEGEND PIZZAS ---
  {
    id: 'leg-1',
    name: 'Chicken Tikka Pizza',
    category: 'legend',
    description: 'Traditional BBQ tikka chicken, onions, loaded mozzarella & aromatic herbs.',
    image: ASSETS.heroPizza,
    isPizza: true,
    prices: LEGEND_PRICES,
    badge: 'Classic',
  },
  {
    id: 'leg-2',
    name: 'Chicken Fajita Pizza',
    category: 'legend',
    description: 'Smoky fajita chicken, crisp bell peppers, diced onions & authentic rich pizza marinara sauce.',
    image: ASSETS.crownCrust,
    isPizza: true,
    prices: LEGEND_PRICES,
  },
  {
    id: 'leg-3',
    name: 'Creamy Twist Pizza',
    category: 'legend',
    description: 'Garlic cream sauce base, tender herb-grilled chicken, sweet bell peppers & double cheese.',
    image: ASSETS.heroPizza,
    isPizza: true,
    prices: LEGEND_PRICES,
  },
  {
    id: 'leg-4',
    name: 'Cheese Lover Pizza',
    category: 'legend',
    description: 'Double extra mozzarella and golden cheddar layer with oregano blend.',
    image: ASSETS.crownCrust,
    isPizza: true,
    prices: LEGEND_PRICES,
    isVegetarian: true,
  },

  // --- CROWN CRUST ---
  {
    id: 'cr-1',
    name: 'Crown Crust Special Pizza',
    category: 'crown',
    description: 'Iconic crown-shaped pizza crust stuffed with juicy chicken kebabs or mozzarella cheese pockets.',
    image: ASSETS.crownCrust,
    isPizza: false,
    isCrown: true,
    variants: [
      { size: 'Medium (9")', price: 1150 },
      { size: 'Large (12")', price: 1550 },
      { size: 'X-Large (15")', price: 2450 },
    ],
    badge: 'Signature Crown',
  },

  // --- ARTISAN BURGERS ---
  {
    id: 'brg-1',
    name: 'Champs Crispy Zinger Burger',
    category: 'burgers',
    description: 'Crispy deep-fried whole chicken fillet with signature garlic mayo and iceberg lettuce on a toasted sesame bun.',
    image: ASSETS.burgerShowcase,
    price: 420,
    badge: 'Best Seller',
    isSpicy: true,
  },
  {
    id: 'brg-2',
    name: 'Champs Jumbo Double Patty Burger',
    category: 'burgers',
    description: 'Double tender spiced chicken patties layered with molten cheddar cheese, pickled gherkins & special sauce.',
    image: ASSETS.burgerShowcase,
    price: 580,
  },
  {
    id: 'brg-3',
    name: 'Grilled Fillet Cheese Burger',
    category: 'burgers',
    description: 'Herb-marinated grilled chicken breast topped with melted cheese slice, caramelized onions & smoky BBQ drizzle.',
    image: ASSETS.burgerShowcase,
    price: 490,
  },

  // --- SANDWICHES & PASTAS ---
  {
    id: 'sp-1',
    name: 'Champs Special Club Sandwich',
    category: 'sandwich_pasta',
    description: 'Triple-decker toasted sandwich with grilled chicken, cheese, mayo garlic dressing & crisp golden french fries.',
    image: ASSETS.clubSandwich,
    price: 600,
  },
  {
    id: 'sp-2',
    name: 'Oven Baked Macaroni Pasta',
    category: 'sandwich_pasta',
    description: 'Penne macaroni pasta loaded with chicken, black olives, white cream sauce & golden melted mozzarella.',
    image: ASSETS.creamyPasta,
    price: 650,
  },
  {
    id: 'sp-3',
    name: 'Fettuccine Alfredo Pasta',
    category: 'sandwich_pasta',
    description: 'Tender fettuccine ribbons tossed in velvety parmesan garlic cream with seasoned grilled chicken chunks.',
    image: ASSETS.creamyPasta,
    price: 600,
  },

  // --- WRAPS & SHAWARMA ---
  {
    id: 'ws-1',
    name: 'Crispy Zinger Wrap',
    category: 'wrap_shawarma',
    description: 'Golden fried chicken zinger strip wrapped with lettuce, cheese & spicy dip in toasted tortilla.',
    image: ASSETS.crispyZingerWrap,
    price: 500,
  },
  {
    id: 'ws-2',
    name: 'Special Open Shawarma Platter',
    category: 'wrap_shawarma',
    description: 'Platter of shredded chicken shawarma, fresh salad, garlic toum dip & served with 2 fresh pita breads.',
    image: ASSETS.openShawarmaPlatter,
    price: 550,
  },
  {
    id: 'ws-3',
    name: 'Zinger Shawarma Roll',
    category: 'wrap_shawarma',
    description: 'Crispy zinger chicken with garlic sauce and secret spices rolled in soft shawarma bread.',
    image: ASSETS.zingerShawarmaRoll,
    price: 380,
  },

  // --- FRIES & STARTERS ---
  {
    id: 'plt-3',
    name: 'Loaded Cheese Fries (Regular)',
    category: 'fries_starters',
    description: 'Golden fries smothered in hot cheddar cheese sauce, diced jalapeños, and spiced chicken bits.',
    image: ASSETS.loadedFries,
    price: 700,
    badge: 'Popular',
  },
  {
    id: 'plt-4',
    name: 'Plain French Fries (Regular)',
    category: 'fries_starters',
    description: 'Crisp golden salted potato fries cooked fresh to order in clean oil.',
    image: ASSETS.crispyFries,
    price: 200,
    isVegetarian: true,
  },
  {
    id: 'plt-2',
    name: 'Oven Baked BBQ Wings (6 Pcs)',
    category: 'fries_starters',
    description: 'Juicy chicken wings oven-baked with savory caramelized barbecue sauce glaze — 6 pieces.',
    image: ASSETS.bakedWings,
    price: 380,
  },
  {
    id: 'plt-5',
    name: 'Mozzarella Cheese Sticks (4 Pcs)',
    category: 'fries_starters',
    description: 'Golden crumb-fried Italian mozzarella sticks with molten stretchy cheese center & marinara dip.',
    image: ASSETS.mozzarellaSticks,
    price: 390,
    isVegetarian: true,
  },
  {
    id: 'plt-1',
    name: 'Champs Mega Party Platter',
    category: 'fries_starters',
    description: '3 Pcs Spin Rolls + 6 Pcs Oven Baked Wings + 1 Portion Regular Fries + 1 Signature Dip Sauce.',
    image: ASSETS.starterShowcase,
    price: 800,
    badge: 'Popular Feast',
  },
  {
    id: 'dip-1',
    name: 'Signature Garlic Mayo Dip',
    category: 'fries_starters',
    description: 'Creamy homemade garlic mayo dipping sauce bowl with fresh herbs.',
    image: ASSETS.starterShowcase,
    price: 80,
  },

  // --- COLD DRINKS & SODA ---
  {
    id: 'drk-1',
    name: 'Chilled Soda Tin Can (250ml)',
    category: 'drinks',
    description: 'Ice cold carbonated beverage (Coke, Sprite, Fanta, or Dew) in 250ml tin can.',
    image: ASSETS.coldDrinks,
    price: 130,
  },
  {
    id: 'drk-2',
    name: 'Chilled Soft Drink (1.5 Liter)',
    category: 'drinks',
    description: 'Family party size 1.5 Liter cold drink bottle (Coke / Sprite / Fanta / Dew).',
    image: ASSETS.coldDrinks,
    price: 230,
    badge: 'Family Size',
  },
  {
    id: 'drk-3',
    name: 'Chilled Soft Drink Bottle (500ml)',
    category: 'drinks',
    description: 'Personal 500ml chilled soft drink bottle.',
    image: ASSETS.coldDrinks,
    price: 120,
  },

  // --- PURE MINERAL WATER (SEPARATE SECTION) ---
  {
    id: 'wat-1',
    name: 'Chilled Pure Mineral Water (500ml)',
    category: 'water',
    description: 'Chilled pure drinking mineral water 500ml bottle, clean and crisp refreshment.',
    image: ASSETS.mineralWater,
    price: 60,
    isVegetarian: true,
    badge: 'Chilled',
  },
  {
    id: 'wat-2',
    name: 'Chilled Pure Mineral Water (1.5 Liter)',
    category: 'water',
    description: 'Chilled pure drinking mineral water 1.5 Liter family size bottle.',
    image: ASSETS.mineralWater,
    price: 100,
    isVegetarian: true,
    badge: 'Family Size',
  },

  // --- DESSERTS & SWEETS ---
  {
    id: 'des-1',
    name: 'Hot Fudge Brownie with Ice Cream',
    category: 'desserts',
    description: 'Warm chocolate fudge brownie served with a scoop of vanilla ice cream & dark chocolate drizzle.',
    image: ASSETS.fudgeBrownie,
    price: 450,
    badge: 'Sweet Treat',
  },
  {
    id: 'des-2',
    name: 'Premium Soft Ice Cream (2 Scoops)',
    category: 'desserts',
    description: 'Two generous scoops of velvety rich artisan ice cream served in a dessert glass bowl.',
    image: ASSETS.iceCream,
    price: 250,
    isVegetarian: true,
  },
];

export interface ParentDeal {
  id: string;
  name: string;
  type: 'starter' | 'burger';
  tag?: string;
  tagColor?: string;
  items: string[];
  price: number;
  oldPrice?: number;
  saveAmount?: number;
}

export const STARTER_DEALS: ParentDeal[] = [
  {
    id: 'deal-starter-1',
    name: 'Solo Starter Deal',
    type: 'starter',
    saveAmount: 71,
    oldPrice: 470,
    price: 399,
    items: ['3 Pcs Oven Baked Wings', '1 Regular Fries', '1 Dip Sauce'],
  },
  {
    id: 'deal-starter-2',
    name: 'Snack Attack Deal',
    type: 'starter',
    saveAmount: 136,
    oldPrice: 735,
    price: 599,
    items: ['3 Pcs Spin Roll', '5 Pcs Chicken Nuggets', '1 Dip Sauce'],
  },
  {
    id: 'deal-starter-3',
    name: 'Loaded Crunch Deal',
    type: 'starter',
    saveAmount: 161,
    oldPrice: 960,
    price: 799,
    items: ['1 Small Loaded Cheese Fries', '4 Pcs Strips Bites', '1 NR Drink'],
  },
  {
    id: 'deal-starter-4',
    name: 'Duo Appetizer Box',
    type: 'starter',
    saveAmount: 241,
    oldPrice: 1440,
    price: 1199,
    items: ['6 Pcs Oven Baked Wings', '12 Pcs Chicken Poppers', '1 Large Masala Fries', '2 Dip Sauces'],
  },
  {
    id: 'deal-starter-5',
    name: 'Ultimate Starter Fiesta',
    type: 'starter',
    saveAmount: 371,
    oldPrice: 1870,
    price: 1499,
    items: ['3 Pcs Spin Roll', '6 Pcs Wings', '4 Pcs Strips Bites', '1 Small Cheese Stick', '2 Dips'],
  },
];

export const BURGER_DEALS: ParentDeal[] = [
  {
    id: 'deal-burger-1',
    name: 'Value Deal 1',
    type: 'burger',
    saveAmount: 120,
    oldPrice: 670,
    price: 550,
    items: ['1 Zinger Burger', 'Regular Fries', 'NR Drink'],
  },
  {
    id: 'deal-burger-2',
    name: 'Value Deal 2',
    type: 'burger',
    saveAmount: 100,
    oldPrice: 800,
    price: 700,
    items: ['1 Jumbo Burger', 'Regular Fries', 'NR Drink'],
  },
  {
    id: 'deal-burger-3',
    name: 'Value Deal 3',
    type: 'burger',
    saveAmount: 160,
    oldPrice: 800,
    price: 640,
    items: ['1 Fillet Burger (w/ Cheese)', 'Regular Fries', 'NR Drink'],
  },
  {
    id: 'deal-burger-4',
    name: 'Value Deal 4 — Couple Deal',
    type: 'burger',
    saveAmount: 61,
    oldPrice: 860,
    price: 799,
    items: ['2 Zinger Burgers', '0.5 Liter Drink'],
  },
];
